#ifndef XML_H_
#define XML_H_

#include "opencv2/opencv.hpp"
#include <iostream>

using namespace std;
using namespace cv;

class XML
{
public:
    const int imageWidth = 640;
    const int imageHeight = 480;
    Size imageSize = Size(imageWidth, imageHeight);
public:
    void write_map_yml();
    void write_cam_yml();
    void read_map_yml(Mat &mapLx, Mat &mapLy, Mat &mapRx, Mat &mapRy);
    void read_map_yml(Rect &validROIL, Rect &validROIR);
    void read_map_yml(Mat &Q);

    void getlookuptable(Mat mapx, Mat mapy, Mat &mapx_inv, Mat &mapy_inv, bool type);//type: 0->L  1->R
};
#endif // !XML_H_

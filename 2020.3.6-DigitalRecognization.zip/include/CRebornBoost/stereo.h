#ifndef STEREO_H_
#define STEREO_H_

#include "opencv2/opencv.hpp"  
#include <iostream>  
#include "EnemyClass/CArmour.h"

using namespace std;
using namespace cv;


struct Matched
{
	Point2f LeftPoint;
	Point2f RightPoint;

	Point2f L_LPoint;
	Point2f R_LPoint;

	Point2f L_RPoint;
	Point2f R_RPoint;
};

class Stereo
{
public:
	int Parallax = 200;

	Mat Q; //= Mat::zeros(cv::Size(4, 4), CV_32FC1);
	Mat mapLx_inv, mapLy_inv, mapRx_inv, mapRy_inv;
	Mat ML;
	Rect validROIL, validROIR;

	vector<Point2f> Left_, Right_;
	vector<Point2f> Left_L, Right_L;
	vector<Point2f> Left_R, Right_R;
	vector<Matched> matchedPoints;
	vector<Point3f> coordinates3D;
	vector<Point3f> LeftLight3D, RightLight3D;

private:
	float m_GunYawIn;		   //�յ�����̨ˮƽ�Ƕ�
	float m_GunPitchIn;		   //�յ�����̨��ֱ�Ƕ�

public:
	void stereo_init();
	void rectification(vector<Point2f> Left, vector<Point2f> Right);
	void rectification(vector<Point2f>, vector<Point2f>, vector<Point2f>, vector<Point2f>, vector<Point2f>, vector<Point2f>);
	void getCompare();
	void solve3Dcoordinate();
	vector<CArmour> compute(vector<CArmour> ArmourVector);
    void ConvertCentralPos();
	vector<Point3f> GetPos();
	void SetGunAngle(float Yaw, float Pitch);
    
private:
	void Get_ML();
};
#endif // !STEREO_H_

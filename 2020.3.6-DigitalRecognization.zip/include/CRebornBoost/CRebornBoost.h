#ifndef BOOST_H
#define BOOST_H
// #define G 9.8
#include <iostream>
#include <opencv2/opencv.hpp>
#include <vector>
#include "stereo.h"
#include "imm_class.h"
#include "trackandahp.h"
#include "xml.h"
#include "Prediction/trackandahp.h"

using namespace std;
using namespace cv;

#define DEBUG

struct Arm
{
    double min_area;
    Mat ROI;
    Point TLPoint;
};

// class Armor
// {
// public:
//     Armor(Point2f _center)
//     {
//         center = _center;
//     }
// private:
//     Point2f center;
// };
Point2f getCenter_mu(vector<Point> contour);
Point2f getCenter_rect(vector<Point> contour);

class CRebornBoost
{
private:
    Mat srcL, srcR, rangeL, rangeR;
    vector<vector<Point>> glo_contoursL, glo_contoursR;
    vector<Arm> armsL, armsR; 
    
    Mat kernel_E_3 = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
    Mat kernel_E_5 = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));
    int n_dilate;
    double bullet_speed;

public:
    CRebornBoost();
    ~CRebornBoost();
    void Range();

    void Glo_Contours();
    void Arms();
    void Armors();
    void Find(Mat frameL, Mat frameR);
    void DrawRotatedRect(Mat& frame, RotatedRect& rect, Scalar color, int stroke);
    void ClearAll();

    void SolvePitchYaw(float Pos_X, float Pos_Y, float Pos_Z);
//    void ConvertCamPos();
    // void ComputeAngle();
    double PitchAngle, YawAngle;
    double Distance;
    bool clear = 0;
    bool ifAim;
    char color;
    // Stereo stereo;
    vector<Point2f> armorsL, armorsR;

    bool Aim()
    {
        return (!armorsL.empty() && !armorsR.empty());
    }
};

#endif // BOOST_H

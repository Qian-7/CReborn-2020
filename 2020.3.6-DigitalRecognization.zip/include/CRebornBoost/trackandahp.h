#pragma once
#include <opencv2/opencv.hpp>  
#include <iostream>
#include "imm_class.h"

//using namespace Eigen;
using namespace cv;
using namespace std;

struct BoostTrack {
	long int			id;							//轨迹ID
	Point3d				center;						//滤波后中心
	//float				height;						//高度
	KalmanFilter		KF[2];						//轨迹的卡尔曼滤波器
	int					age;						//总数量
	int					totalVisibleCount;			//可视数量
	int					consecutiveInvisibleCount;	//不可视数量
	//int				car_type;					//识别到的车辆类型
	float				car_distance;				//车辆距离
	Boostimm					_imm;
};

class Boosttrack_ahp
{
private:
	float				T = 0.02;					//每帧时间
	BoostTrack				Newobservetrack;			//新出现的目标
	Point3d				preCelectedpoint;			//选择打击的目标

	vector<BoostTrack>		tracks;
	vector<Point3d>		centroids;
	//vector<float>		heights;
	//vector<Point3f>		worldCentroids;
	//Point2f				PitchYaw;
	//vector<int>		cartypes;
	vector<float>		dis;
	vector<int>			assignments;
	vector<int>			unassignedTrack;
	vector<int>			unassignedDetection;
	long int			nextId = 0;


private:
	void getattribute(vector<Point3d> centers, Point3d m_preCel);//, std::vector<int> car_type
	void predictNewLocationsOfTracks();  //根据位置进行卡尔曼预测
	void detectionToTrackAssignment();   //匈牙利匹配
	void updataAssignedTracks();         //分配好的轨迹更新
	void updataUnassignedTracks();       //未分配的轨迹更新
	void deletedLostTracks();            //删除丢失的轨迹
	void createNewTracks();              //创建新轨迹
	void the_selected_target();			 //确定预测的目标


	//匈牙利匹配算法 
	void  munkres(Mat &costMat, int costOfNonAssignment,					//costMat成本矩阵 costOfNonAssignment匹配距离阈值   
		vector<int> &assignment, vector<int> &unassignedTracks,	//assignment分配矩阵 unassignedTracks未分配轨迹
		vector<int> &unassignedDetections);						//unassignedDetections未分配目标


public:
	bool				appear_possible_newflag = 0;
	bool				have_Newobservetrack = 0;

	Point3d ture_hit_predict_kalman();//实际打击目标的卡尔曼预测
	//Point2f ture_hit_predict_kalman(int);
	void comprehensive(vector<Point3d> centers, Point3d m_preCel);//, vector<int> car_type

};

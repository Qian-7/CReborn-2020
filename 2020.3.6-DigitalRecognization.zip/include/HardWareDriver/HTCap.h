﻿#pragma once
#include "CameraApi.h" //相机SDK的API头文件
#include <opencv2/opencv.hpp>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include <iostream>

#include "time.h"
#include "string.h"

using namespace cv;
using namespace std;

//摄像头内参矩阵
extern Mat HTMatrix_640x480;
extern Mat HTMatrix_1280x1024;
//摄像头畸变矩阵
extern Mat HTcoeMat_640x480;
extern Mat HTcoeMat_1280x1024;

class HTCap
{
  public:
	HTCap(){};
	HTCap(int cap_Speedmode = 1, bool auto_Exp = 0, Size frameSize = Size(640, 480), int cap_expTime = 3);
	~HTCap();

	int HTinit();
	int HTuninit();

	int setAll();
	int setExposureTime(bool auto_exp, int expt);
	int setVideoSize(Size frameSize);
	int setVideoSpeed(int speedmode);//0:lowspeed 1:highspeed
	int setVideoFormat(Size frameSize);
	int getCapMatrix(Mat& matrix,Mat& coeMat);

	int startCap();
	int pauseCap();
	int stopCap();

	int getWidth();
	int getHeight();
	Size getVideoSize();


	void restartCapture();

	int getFrameCount()
	{
		return cur_frame;
	}

	HTCap &operator>>(cv::Mat &image);

  public:
	int camnum;
	int fd;

  private:
	unsigned char           * g_pRgbBuffer;     //处理后数据缓存区
	int						iCameraCounts = 1;
    int						iStatus=-1;
    tSdkCameraDevInfo		tCameraEnumList;
    int						hCamera;
    tSdkCameraCapbility		tCapability;      //设备描述信息
    tSdkFrameHead			sFrameInfo;
    tSdkImageResolution		pImgRes;
    BYTE*					pbyBuffer;
    int						iDisplayFrames = 10000;
    int						channel=3;

	int 					cur_frame = 0;

	bool 					m_autoExp = 0;
	int 					m_capExpTime = 3;
	int 					m_capSpeed = 1;
	Size 					m_frameSize = Size(640, 480);
	Mat 					m_Matrix;
	Mat 					m_coeMat;

};














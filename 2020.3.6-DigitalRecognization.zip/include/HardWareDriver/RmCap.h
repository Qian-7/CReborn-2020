﻿#pragma once
#include "Utility/Params.h"

//摄像头内参矩阵
extern Mat Matrix_640x480;
extern Mat Matrix_1280x720;
extern Mat Matrix_1280x1024;
extern Mat Matrix_1920x1080;

//摄像头畸变矩阵
extern Mat coeMat_640x480;
extern Mat coeMat_1280x720;
extern Mat coeMat_1280x1024;
extern Mat coeMat_1920x1080;

class RmCap
{
  public:
	RmCap(){};
	RmCap(const char *device, int size_buffer = 1, Size frameSize = Size(640, 480), int cap_expTime = 38, bool auto_Exp = 0, bool mjpg = 1);
	~RmCap();

	bool startStream();
	bool closeStream();
	bool setExposureTime(bool auto_exp, int t);
	bool setVideoFormat(int width, int height, bool mjpg = 1);
	bool changeVideoFormat(int width, int height, bool mjpg = 1);
	bool getVideoSize(int &width, int &height);
	bool getCapMatrix(Mat &matrix, Mat &coeMat);

	int getWidth();
	int getHeight();

	bool setVideoFPS(int fps);
	bool setBufferSize(int bsize);
	void restartCapture();
	void setWhiteBalance(int val);
	int getFrameCount()
	{
		return cur_frame;
	}

	void info();

	RmCap &operator>>(cv::Mat &image);

  public:
	int camnum;
	int fd;

  private:
	void cvtRaw2Mat(const void *data, cv::Mat &image);
	bool refreshVideoFormat();
	bool initMMap();
	int xioctl(int fd, int request, void *arg);

	struct MapBuffer
	{
		void *ptr;
		unsigned int size;
	};
	Mat m_Matrix;
	Mat m_coeMat;
	unsigned int capture_width;
	unsigned int capture_height;
	unsigned int format;
	unsigned int buffer_size;
	unsigned int buffr_idx;
	unsigned int cur_frame;

	MapBuffer *mb;
	const char *video_path;
};

void CamSetMode(RmCap &cap1, RmCap &cap2, RmCap &cap3, int picsize, bool uphealthy);

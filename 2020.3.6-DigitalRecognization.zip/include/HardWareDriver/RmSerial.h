﻿#pragma once

#define RM_USB_SERIAL 0
#define RM_SERIAL 1
#define RM_USB 2

class RmSerial
{
  public:
	RmSerial();
	RmSerial(int PortNum, int BiteSpeed = 19200, int PortMode = RM_USB_SERIAL,
			 char DataBits = 8, char ParityBits = 'N', char StopBits = 1);
	~RmSerial();

	/**
	 * Funtion:		InitPort()
	 * Description: 初始化串口的波特率以及传输参数
	 * Calls:      NONE
	 * Input:		NONE
	 * Output:		NONE
	 * Return:		true 串口打开成功\false 串口打开失败
	 * Others:		设置失败时输出"SetUp Serial Error"
	 */
	bool InitPort();

	/**
	 * Funtion:		 OpenPort()
	 * Description:  打开相应串口类型的串口
	 * Calls:       NONE
	 * Input:       NONE
	 * Output:      NONE
	 * Return:      true:串口打开成功 false:串口打开失败
	 * Others:      打开失败将会报错"Open Serial Error"
	 */
	bool OpenPort();

	/**
	 * Funtion : ClosePort() 
	 * Description : 关闭串口 
	 * Calls : NONE 
	 * Input : NONE 
	 * Output : NONE 
 	 * Return : true : 串口关闭成功 false : 串口关闭失败 
 	 * Others : 打开失败将会报错 "Close Serial Error" 
	 */
	bool ClosePort();

	/**
	 * Funtion:		ReadData(unsigned char *dataGet, int dataLength)
	 * Description: 从串口文件流中读入数据
	 * Calls:      NONE
	 * Input:		unsigned char *dataGet: 需要传入数据的数组\
					int dataLength:			需要传入数据的长度
	 * Output:		unsigned char *dataGet
	 * Return:		true: 读取成功\false: 读取失败
	 * Others:		读取失败时输出"Read Error"
	 */
	bool ReadData(unsigned char *dataIn, int dataLength);
	/**
	 * Funtion:		WriteData(unsigned char *dataSet, int dataLength)
	 * Description: 将dataSet传入进串口文件流中
	 * Calls:      NONE
	 * Input:		unsigned char *dataSet: 需要传出数据的数组\
					int dataLength:			需要传出数据的长度
	 * Output:		NONE
	 * Return:		true: 写入成功\false: 写入失败
	 * Others:		写入失败时会输出"Write Error"
	 */
	bool WriteData(unsigned char *dataOut, int dataLength);
	int m_PortID;	  //打开串口的文件句柄	
  private:
	int m_PortNum;   //串口编号
	int m_BiteSpeed; //串口波特率
	int m_PortMode;  //串口类型： 0\USB串口 1\串口 2\USB
	//Tips:USB不可用


	int m_DataBits;	//数据位 取值7或8
	char m_ParityBits; //校验类型 取值N、E、O、S
	int m_StopBits;	//停止位 取值1或者2
};

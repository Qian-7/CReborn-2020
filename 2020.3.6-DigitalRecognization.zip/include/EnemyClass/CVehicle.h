﻿#pragma once
#include "Utility/Params.h"
#include "EnemyClass/CArmour.h"
class CVehicle
{
  public:
	CVehicle();
	CVehicle(Rect PosRect, uchar Type);
	~CVehicle();

	Rect m_VehiclePosRect;				   //敌方车辆图像中区域
	uchar m_VehicleType;				   //敌方车辆类型：0 英雄 |  1 步兵  |  2 哨兵 | 3 工程 | 4 基地
	vector<CArmour> m_VehicleArmourVector; //敌方车辆装甲板

	void Clear();

	/**
	*Funtion:		Show(Mat displayImg)
	*Description:	在displayImg上画出车的位置以及装甲的位置
	*Calls:			NONE
	*Input:			displayImg: 显示的图像
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void Show(Mat DisplayImg);
};

﻿#pragma once
#include <iostream>
#include <opencv2/opencv.hpp>
#include <opencv2/ml.hpp>
#include <opencv2/dnn.hpp>
#include <math.h>
#include <stdlib.h> // 标准函数库定义
#include <stdio.h>  // 标准输入输出定义
#include <unistd.h> // Unix标准函数定义
#include <termios.h>
#include <sys/types.h> // Unix/Linux 基本系统数据类型
#include <sys/stat.h>  // unix/linux系统定义文件状态所在的伪标准头文件
#include <linux/fs.h>
#include <fcntl.h> // PPSIX终端控制定义
#include <errno.h>

using namespace std;
using namespace cv;
using namespace ml;

struct BrightLight
{
	Point2f top;
	Point2f center;
	Point2f bottom;
	double angle;
	RotatedRect minarearect;
	bool ifPaired;
};

//~~~~~~~~~~~~~~~~~~~~~~~~函数~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
/**
 * Funtion:		RotatedXvalueSort(RotatedRect a, RotatedRect b)
 * Description:	判断两个旋转矩形的X坐标值大小，可利用sort()排序
 * Calls:			NONE
 * Input:			RotatedRect a,b:需要判断的两个旋转矩形
 * Output:		NONE
 * Return:		Bool:若X坐标值a >= b返回false,其他情况返回TRUE
 * Others:		可利用sort()调用该函数完成旋转矩形X坐标值的排序
 */
bool RotatedXvalueSort(RotatedRect a, RotatedRect b);

/**
 * Funtion:		LightXvalueSort(BrightLight a, BrightLight b)
 * Description:	判断两个旋转矩形的X坐标值大小，可利用sort()排序
 * Calls:			NONE
 * Input:			BrightLight a,b:需要判断的两个旋转矩形
 * Output:		NONE
 * Return:		Bool:若X坐标值a >= b返回false,其他情况返回TRUE
 * Others:		可利用sort()调用该函数完成旋转矩形X坐标值的排序
 */
bool LightXvalueSort(BrightLight a, BrightLight b);

/**
 * Funtion:		RectAreaSort(Rect a, Rect b)
 * Description:	判断两个矩形的面积大小，可利用sort()排序
 * Calls:			NONE
 * Input:			Rect a,b:需要判断的两个矩形
 * Output:		NONE
 * Return:		Bool:若面积值 a <= b返回false,其他情况返回TRUE
 * Others:		可利用sort()调用该函数完成矩形面积大小的排序
 */

bool RectAreaSort(Rect a, Rect b);
/**
 * Funtion:		RmCapSetUp()
 * Description:	设置摄像头分辨率、内参矩阵、畸变矩阵
 * Calls:			NONE
 * Input:			CAP_FORMAT
 * Output:		NONE
 * Return:		NONE
 * Others:		NONE
 */

bool MakeRectInLimit(Rect &rect, Mat limitImg);

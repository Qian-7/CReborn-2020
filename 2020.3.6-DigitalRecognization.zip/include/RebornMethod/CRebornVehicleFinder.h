﻿#pragma once
#include "Utility/Params.h"
#include "EnemyClass/CVehicle.h"

//------------------CRebornVehicleFinder 设置---------------
extern String defaultVehicleWeightsPath; //步兵检测模型
extern String defaultVehiclePrototxt;

class CRebornVehicleFinder
{
  public:
    CRebornVehicleFinder(String weightsPath = defaultVehiclePrototxt,String prototxt = defaultVehicleWeightsPath);
	~CRebornVehicleFinder();
    void InitNet(String weightsPath = defaultVehicleWeightsPath,String prototxt = defaultVehiclePrototxt);
    /**
	 * Funtion:		VehicleFind()
	 * Description:	利用深度学习在RmCap中寻找出CVehicle位置
	 * Calls:			NONE
	 * Input:			NONE
	 * Output:		NONE
	 * Return:		vector<CVehicle>
	 * Others:		NONE
	 */
	vector<CVehicle> VehicleFind(Mat m_InitImg);

  private:
	dnn::Net m_Net; 

};

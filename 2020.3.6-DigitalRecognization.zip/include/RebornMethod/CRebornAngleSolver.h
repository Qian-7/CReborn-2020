﻿#pragma once
#include "Utility/Params.h"
#include "EnemyClass/CVehicle.h"
#include "Prediction/trackandahp.h"
#include <fstream>
//------------------CRebornAngleSolver  设置-------------------

#define G 9.8015f		//北京重力加速度
#define AIRDRAG_NUM 0.100f   //空气阻力参数
#define ITERATION_TIMES 20 //迭代次数

extern float terranceX; //摄像头相对于云台旋转中心的X长度(单位 cm)
extern float terranceY; //摄像头相对于云台旋转中心的Y高度(单位 cm)
extern float terranceZ; //摄像头相对于云台旋转中心的Z长度(单位 cm)

extern float barrelHeight;   //摄像头相对于枪管的垂直高度(单位 cm)
extern float barrelDistance; //摄像头相对于枪管的水平长度(单位 cm)

extern float Tx;	//以Yaw轴为原点，Pitch轴与枪管焦点为坐标的X值    ********
extern float Ty;	//以Yaw轴为原点，Pitch轴与枪管焦点为坐标的Y值    ********
extern float Tz;	//以Yaw轴为原点，Pitch轴与枪管焦点为坐标的Z值    ********
extern float Gx;	//以Pitch轴与枪管焦点为原点，摄像头坐标的X值    ********
extern float Gy;	//以Pitch轴与枪管焦点为原点，摄像头坐标的Y值    ********
extern float Gz;	//以Pitch轴与枪管焦点为原点，摄像头坐标的Z值    ********

extern float bulletSpeed; //子弹弹速(单位 m/s)

extern ofstream outf;//****************************************************************************

class CRebornAngleSolver
{
  public:
	float m_YawAngleOut;   //输出云台水平角度
	float m_PitchAngleOut; //输出云台垂直角度
	uchar m_DisTance;	  //输出距离
	bool m_IfOutNum;	   //
	int m_IfHero;
	int m_IfHighSpeed;
	CRebornAngleSolver();
	~CRebornAngleSolver();

	/**
	 * Funtion:		SolveArmourAngle(vector<CArmour>& ArmourVector)
	 * Description:	得到自瞄传出的敌车装甲板射击角度
	 * Calls:		ClearAll()/
					ConvertVehilceToWorldPos(vector<CArmour>& ArmourVector)/
					filter()/
					SolvePitchYaw(float Pos_X, float Pos_Y, float Pos_Z)
	 * Input:		vector<CArmour>& ArmourVector：敌车装甲板的容器
	 * Output:		NONE
	 * Return:		NONE
	 * Others:		NONE
	 */
	bool SolveArmourAngle(vector<CArmour> ArmourVector, float Angle_Yaw = 0, float Angle_Pitch = 0);

	/**
	 * Funtion:		SolveVehicleAngle(vector<CVehicle>& VehicleVector)
	 * Description:	得到自瞄传出的敌车射击角度
	 * Calls:		ClearAll()/
					ConvertVehilceToWorldPos(vector<CVehicle>& VehicleVector)/
					filter()/
					SolvePitchYaw(float Pos_X, float Pos_Y, float Pos_Z)
	 * Input:		vector<CVehicle>& VehicleVector：敌车的容器
	 * Output:		NONE
	 * Return:		NONE
	 * Others:		NONE
	 */
	bool SolveVehicleAngle(vector<CVehicle> VehicleVector, float Angle_Yaw = 0, float Angle_Pitch = 0);
	Point2f SolveHerosAngle(float big_P,float big_Y,float  small_P,float small_Y,Point3f posBigToSmall,float speed);
  private:
	track_ahp m_Predict;	   //预测处理实例
	Mat m_DebugFrame;		   //显示运行情况
	float m_GunYawIn;		   //收到的云台水平角度
	float m_GunPitchIn;		   //收到的云台垂直角度       
	Point2f m_NearestCarPoint; //离摄像头中心最近的装甲板位置
	Point3f m_Predict_target;  //预测的位置

	vector<Point3f> m_worldCenter; //装甲板center世界坐标****
	vector<Point3f> m_worldLeftLight; //装甲板leftlight世界坐标****
	vector<Point3f> m_worldRightLight; //装甲板rightlight世界坐标****
	vector<Point2f> m_armorCenter; //装甲板中心(以地面为坐标系)****
	vector<double>	m_armorAngle;

	Mat M;
	/**
	*Funtion:		InitAngle(float Yaw, float Pitch)
	*Description:	初始化车现在的陀螺仪值
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void SetGunAngle(float Yaw, float Pitch);
	void ConvertArmourToWorldPos(vector<CArmour> ArmourVector);
	void filter();
    Point3f SolvePitchYaw(float Pos_X, float Pos_Y, float Pos_Z ,float Speed);
	/**
 * this function about solve the angle of Ballistic model with air_Drag
 * aimPos_x:The aim position in x axis 
 * aimPos_y:The aim position in y axis
 * v:  the bullet speed
 * m:  the quality of the bullet
 * iteration_times: The max iteration_times
 **/
	double solveParabolaAngle(double aimPos_x, double aimPos_y, double v, int iteration_times = 10);
	/**
 * this function about solve the angle of linear model
 * aimPos_x:The aim position in x axis 
 * aimPos_y:The aim position in y axis
 **/
	double solveLinearAngle(double aimPos_x, double aimPos_y);
	/**
 * this function to solve the cost about time in direction abour x axis
 * C:The friction coefficient of the sphere in the air(0.47)
 * p:The air density(1.293kg/m^3 when temperature = 0)
 * S:The contact area about a object
 * v_x:the horizontal direction speed of the object 
 * m:the quality of the object
 **/
	double airDrag_t(double C, double p, double S, double pos_x, double v_x, double m);
	double airDrag_t(double pos_x, double v_x, double airDrag_num);
	/**
 * this function to solve the distance of direction about y axis
 * v_y:The speed in y axis
 * g: The local gravity acceleration
 * t: The fly time
 **/
	double gravity_distance(double v_y, double g, double t);
	void InitDebugFrame();
	void clear();
	void GetM();
};

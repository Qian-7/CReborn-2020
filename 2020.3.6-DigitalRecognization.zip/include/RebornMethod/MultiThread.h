#pragma once

	#include "Utility/Params.h"
	#include<mutex>
	#include<thread>
	#include<time.h>
	#include "string.h"

	#include "RebornMethod/CRebornVehicleFinder.h"
	#include "RebornMethod/CRebornArmorFinder.h"
	#include "RebornMethod/CRebornPosSetter.h"
	#include "RebornMethod/CRebornAngleSolver.h"
	#include "KcfTrack/kcftracker.hpp"
	//#include "HardWareDriver/RmCap.h"
	#include "HardWareDriver/HTCap.h"
	//#include "HardWareDriver/RsCap.h"
	#include "HardWareDriver/RmSerial.h"
	#include "CRebornBoost/stereo.h"



using namespace std;
using namespace cv;

class MultiThread
{
private:
	Mat rsFrame;
	string buffer;
	mutex mtx, mtxx;
	unsigned char Str[150];
	vector<CArmour> vArmour;
	float P, Y;
	bool IfHero = 0;
	bool IfHighSpeed = 0;

	


public:
	void ImageConsumer();
	void ImageProducter();
	void SolveAngle();


};


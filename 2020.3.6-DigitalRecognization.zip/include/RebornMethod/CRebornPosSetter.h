﻿#pragma once
#include "Utility/Params.h"
#include "HardWareDriver/RmCap.h"
#include "HardWareDriver/HTCap.h"
#include "EnemyClass/CVehicle.h"
//-------------------CRebornPosSetter 设置---------------
#define RM_POS_K_NUM 0
#define RM_POS_PNP 1

#define SMALL_WIG 6.5f //小装甲宽度的一半
#define SMALL_HEI 2.8f  //小装甲高度的一半
#define BIG_WIG 11.25f   //大装甲宽度的一半
#define BIG_HEI 2.8f	//大装甲高度的一半

extern Mat m_SmallArmorMessage; //小装甲板实际信息
extern Mat m_BigArmorMessage;   //大装甲实际信息
extern double m_SmallKNum;
extern double m_BigKNum;
class CRebornPostSetter
{

  public:
	CRebornPostSetter();
	~CRebornPostSetter();
	//        bool SetVehiclePos(vector<CVehicle> &VehicleVector, RsCap &Cap);
	//        vector<CArmour> SetArmourPos(vector<CArmour> ArmourVector, RsCap &Cap);
	//        vector<CArmour> SetArmourPos(vector<CArmour> ArmourVector, int mode);

	vector<CArmour> SetArmourPos(vector<CArmour> ArmourVector, RmCap &Cap, bool ifPnp = RM_POS_PNP);
	vector<CArmour> SetArmourPos(vector<CArmour> ArmourVector, bool ifPnp = RM_POS_PNP);
	vector<CVehicle> SetVehiclePos(vector<CVehicle> VehicleVector, RmCap &Cap, bool ifPnp = RM_POS_PNP);

  private:

	/**
	 * Funtion:		SolvePnpPos(CArmour &Armour)
	 * Description:	利用SolvePnp解算出每个CArmour的位置
	 * Calls:			NONE
	 * Input:			CArmour &Armour 敌方装甲板
	 * Output:		CArmour.m_ArmourPos
	 * Return:		NONE
	 * Others:		NONE
	 */
	bool SolvePnpPos(CArmour &Armour);
};

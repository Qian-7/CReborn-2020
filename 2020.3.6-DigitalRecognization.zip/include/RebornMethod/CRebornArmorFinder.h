﻿#pragma once
#include "EnemyClass/CArmour.h"
#include "EnemyClass/CVehicle.h"
#include"EnemyClass/CLightBlobs.h"
//-------------------CRebornArmourFinder 设置---------------
#define RM_ARMOUR_BLUE 0
#define RM_ARMOUR_RED 1

#define RM_ARMOUR_NORMAL 0
#define RM_ARMOUR_ML 1
#define RM_ARMOUR_DL 2
extern String defaultWeightsPath; //装甲板检测模型
extern String defaultPrototxtPath;
extern String defaultSvmPath;		   //Svm匹配模型
extern const char *ArmourClassNames[]; //装甲板检测类别

extern double angleMin;
extern double minXdis_MaxHeight;
extern double maxXdis_MaxHeight;
extern double kThresh;
extern double hBThresh;
extern double disAgThresh;
extern double yDisThresh;
extern double xDisThresh;
extern double avgThresh;
extern double bigThresh1;
extern double bigThresh2;
extern double smallThresh1;
extern double smallThresh2;

class CRebornArmourFinder
{
public:
	CRebornArmourFinder(bool ifAimRed = RM_ARMOUR_RED, int mode = RM_ARMOUR_NORMAL, String svmPath = defaultSvmPath, String weightsPath = defaultWeightsPath, String prototxt = defaultPrototxtPath);
	~CRebornArmourFinder();
	void InitSvm(String svmPath = defaultSvmPath);
	void InitNet(String weightsPath = defaultWeightsPath, String prototxt = defaultPrototxtPath);
	vector<CArmour> FindArmour(Mat srcImg);
	vector<CArmour> FindArmour(Mat srcImg, Rect rect);
	vector<CVehicle> FindArmourInVehicle(Mat srcImg, vector<CVehicle> VehicleVector);
	bool m_ifAimRed=1;

private:
	int m_mode;		  //0:传统 1:SVM 2:深度学习 default-0
	Ptr<SVM> m_model; //SVM模型
	dnn::Net m_net;   //深度学习模型

	Ptr<SVM> svm_digital ;//数字识别

	vector<CArmour> FindByNormal(Mat srcImg);
	vector<CArmour> FindByMl(Mat srcImg);
	vector<CArmour> FindByDl(Mat srcImg);

	/**
	 * Funtion:		FindHueRoi()
	 * Description:	利用InitImg图像获取其中相应颜色(RED/BLUE)
					的矩形区域，并保存进m_hueRectVector中
	 * Calls:			GetAvgOfRoi()/
					MakeRectInLimit
	 * Input:			NONE
	 * Output:		NONE
	 * Return:		Bool:若发现矩形个数过多，返回FLASE;其他情况返回TRUE
	 * Others:		NONE
	 */
	bool FindHueRoi(Mat srcImg, vector<Rect> &hueRectVector);
	/**
	 * Funtion:		FindBrightLight()
	 * Description:	在处理图像的m_hueRectVector的矩形ROI内进行
					基于亮度信息的二次查找并将其旋转矩形轮廓输
					入到m_brightRotatedRectVector中
	 * Calls:			NONE
	 * Input:			NONE
	 * Output:		NONE
	 * Return:		Bool:若所得的旋转矩形数目过少返回FALSE,其他情况返回TRUE
	 * Others:		NONE
	 */
	bool FindBrightLight(Mat srcImg, vector<Rect> &hueRectVector, vector<RotatedRect> &brightRotatedRectVector);
	bool FindBrightLight(Mat srcImg, vector<Rect> &hueRectVector, vector<BrightLight> &brightlightVector);
	vector<CArmour> SetPairByMl(Mat srcImg, vector<RotatedRect> &brightRotatedRectVector);
	/**
	 * Funtion:		SetPairLights()
	 * Description:	将m_brightRotatedRectVector中的旋转矩形灯条进行配对
					组合成成对灯条并保存在m_pairLightVector中
	 * Calls:			NONE
	 * Input:			NONE
	 * Output:		NONE
	 * Return:		NONE
	 * Others:		NONE
	 */
	vector<CArmour> SetPairLights(Mat srcImg, vector<RotatedRect> &brightRotatedRectVector);
	vector<CArmour> SetPairLights(Mat srcImg, vector<BrightLight> &brightlightVector);
	vector<CArmour> SetPairLights(Mat srcImg,  LightBlobs &lightblobs);
	vector<CArmour> beatMirror(vector<CArmour>);
	/**
	 * Funtion:		GetAvgOfRoi(Mat srcImg, Rect rect)
	 * Description:	计算灰度图srcImg在矩形区域rect内的每个点的平均值
	 * Calls:			NONE
	 * Input:			srcImg:输入所求平均值的灰度图/
					rect:灰度图的矩形ROI
	 * Output:		NONE
	 * Return:		num:所求的平均值
	 * Others:		NONE
	 */
	float GetAvgOfRoi(Mat, Rect, int);
	/**
	 * Funtion:		DrawRotatedRect(Mat srcImg, RotatedRect roRect)
	 * Description:	在输入的图像中画出旋转矩形的区域
	 * Calls:			NONE
	 * Input:			srcImg:输入的图像\
					roRect:需要画的旋转矩形
	 * Output:		NONE
	 * Return:		NONE
	 * Others:		NONE
	 */
	void DrawRotatedRect(Mat, RotatedRect);
	bool findLightBlobs(const cv::Mat &src, LightBlobs &light_blobs);
};

bool sortOfX(CArmour X, CArmour Y);

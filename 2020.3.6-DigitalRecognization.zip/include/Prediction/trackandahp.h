﻿#pragma once
#include <opencv2/opencv.hpp>
#include <iostream>
#include "Prediction/imm_class.h"
#include "Utility/Params.h"

//using namespace Eigen;

using namespace cv;
using namespace std;

extern double imm_time;



struct Track
{
	long int 	id;				   			//轨迹ID
	Point2f 	center;				   		//滤波后中心
	float 		height;				   		//高度
	KalmanFilter KF[3];			   			//轨迹的卡尔曼滤波器
	int 		age;					   	//总数量
	int 		totalVisibleCount;		   	//可视数量
	int 		consecutiveInvisibleCount; 	//不可视数量
	//int		car_type;					//识别到的车辆类型
	float 		car_distance; //车辆距离
	imm 		_imm;
	double 		now_angle;
	double 		last_angle;
	double 		angle_v,f_angle_v;
	double 		Input[3],Output[3];
	vector<Point2f> trackcenters;
};

class track_ahp
{
  private:
	float 			T = 0.020;			//每帧时间
	Track 			Newobservetrack;	//新出现的目标
	Point2f 		preCelectedpoint;	//选择打击的目标

	vector<Track> 	tracks;
	vector<Point2f> centroids;
	vector<float> 	heights;
	vector<double>	Angles;
	//Point2f		PitchYaw;
	//vector<int>	cartypes;
	vector<float> 	dis;
	vector<int> 	assignments;
	vector<int> 	unassignedTrack;
	vector<int> 	unassignedDetection;
	long int nextId = 0;

  private:
	/**
	*Funtion:		getattribute(vector<Point2f> centers)
	*Description:	将一帧中的测量目标位置存入类中，并计算出离摄像头距离
	*Calls:			NONE
	*Input:			centers:测量目标位置
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void getattribute(vector<Point3f> centers, Point2f m_preCel, vector<double> m_armorAngle); //, std::vector<int> car_type
	/**
	*Funtion:		predictNewLocationsOfTracks()
	*Description:	对每个轨迹进行kalman预测
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void predictNewLocationsOfTracks(); //根据位置进行卡尔曼预测
	/**
	*Funtion:		detectionToTrackAssignment()
	*Description:	对已有轨迹位置与测量目标的位置进行匹配
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void detectionToTrackAssignment(); //匈牙利匹配
	/**
	*Funtion:		updataAssignedTracks()
	*Description:	更新能与测量目标能匹配上的轨迹
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void updataAssignedTracks(); //分配好的轨迹更新
	/**
	*Funtion:		updataUnassignedTracks()
	*Description:	更新未能与测量目标能匹配上的轨迹
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void updataUnassignedTracks(); //未分配的轨迹更新
	/**
	*Funtion:		deletedLostTracks()
	*Description:	删除10帧及以上未匹配到目标的轨迹
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void deletedLostTracks(); //删除丢失的轨迹
	/**
	*Funtion:		createNewTracks()
	*Description:	创建新轨迹
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void createNewTracks(); //创建新轨迹
	/**
	*Funtion:		the_selected_target()
	*Description:	选择目标装甲板
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void the_selected_target(); //确定预测的目标

	//匈牙利匹配算法
	void munkres(Mat &costMat, int costOfNonAssignment,			//costMat成本矩阵 costOfNonAssignment匹配距离阈值
				 vector<int> &assignment, vector<int> &unassignedTracks, //assignment分配矩阵 unassignedTracks未分配轨迹
				 vector<int> &unassignedDetections);			//unassignedDetections未分配目标

  public:
	bool appear_possible_newflag = 0;
	bool have_Newobservetrack = 0;

	/**
	*Funtion:		ture_hit_predict_kalman()
	*Description:	预测被选择的目标的运动
	*Calls:			NONE
	*Input:			NONE
	*Output:		NONE
	*Return:		predict:预测后的目标坐标
	*Others:		NONE
	*/
	Point3f ture_hit_predict_kalman(); //实际打击目标的卡尔曼预测
	/**
	*Funtion:		SetPairLights()
	*Description:	对选中目标进行滤波(该函数仅作调试时观察用)
	*Calls:			NONE
	*Input:			x:值要为1
	*Output:		NONE
	*Return:		filter:滤波后目标坐标
	*Others:		NONE
	*/
	Point3f ture_hit_predict_kalman(int);
	/**
	*Funtion:		comprehensive(vector<Point2f> centers)
	*Description:	对轨迹进行预测校正更新
	*Calls:			getattribute(centers);
					predictNewLocationsOfTracks();  //根据位置进行卡尔曼预测
					detectionToTrackAssignment();   //匈牙利匹配
					updataAssignedTracks();         //分配好的轨迹更新
					updataUnassignedTracks();       //未分配的轨迹更新
					deletedLostTracks();            //删除丢失的轨迹
					createNewTracks();              //创建新轨迹
					the_selected_target();
	*Input:			NONE
	*Output:		NONE
	*Return:		NONE
	*Others:		NONE
	*/
	void comprehensive(vector<Point3f> centers, Point2f m_preCel, vector<double> m_armorAngle); //, vector<int> car_type
};

/**
*Funtion:		distance_(Point2f center, Point2f point)
*Description:	计算两点间距离
*Calls:			NONE
*Input:			center:点1
				point:点2
*Output:		NONE
*Return:		dis:两点间距离
*Others:		NONE
*/
float distance_(Point2f center, Point2f point);

/**
*Funtion:		copy_Track(Track *des, Track *source)
*Description:	复制实例类
*Calls:			NONE
*Input:			des:复制到的实例
				source:被复制的实例
*Output:		NONE
*Return:		NONE
*Others:		NONE
*/
void copy_Track(Track *des, Track *source);

/**
*Funtion:		AngleV_Filter(Track *track_)
*Description:	角速度滤波
*Calls:			NONE
*Input:			track_:输入的轨迹
*Output:		out[2]:滤波后的角速度值
*Return:		NONE
*Others:		NONE
*/
void AngletrackV_Filter(Track *track_);

/**
*Funtion:		polynomial_curve_fit(vector<Point> key_point, int n, Mat& A)
*Description:	拟合轨迹
*Calls:			NONE
*Input:			key_point:输入的轨迹点
				n:拟合式阶数
				A:拟合式参数
*Output:		NONE
*Return:		NONE
*Others:		NONE
*/
void polynomial_curve_fit(vector<Point2f> key_point, int n, Mat& A);

/**
*Funtion:		convert_timerelation(vector<Point> key_point, vector<Point> &V_x, vector<Point> &V_y)
*Description:	分别转为与时间相关的Point X，Y
*Calls:			NONE
*Input:			key_point:输入的轨迹点
				V_x:
				V_y:
*Output:		NONE
*Return:		NONE
*Others:		NONE
*/
void convert_timerelation(vector<Point2f> key_point, vector<Point2f> &V_x, vector<Point2f> &V_y);









﻿#pragma once
#include <math.h>
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

struct kalman_XP
{
	Mat X, P;
};

struct kalman_eS
{
	Mat e, S;
};

struct mix_model
{
	Mat x_pro, P;
};

class imm
{
private:
	float T = (float)20.0 / 1000.0; //每帧时间

	Mat qk;
	float a = 1 / 2.0;
	float a_max = 1.0f;
	int MODEL_SIZE = 3; //3个模型

	vector<kalman_XP> XP_IMM; //2个模型各自的估计值
	vector<kalman_eS> eS_IMM; //2个模型各自的预测误差,预测误差协方差矩阵
	mix_model mix_model_IMM;  //2个模型综合的估计值

	Mat pij = (Mat_<float>(MODEL_SIZE, MODEL_SIZE) <<	0.8, 0.1, 0.1,
														0.1, 0.8, 0.1,
														0.1, 0.1, 0.8);
	Mat u_IMM = Mat::zeros(cv::Size(1, MODEL_SIZE), CV_32FC1); //IMM算法模型概率
	Mat c_j;										  //模型混合概率
private:
	void imm_init(Point2f pos);								   //imm初始化
	void kalman_init(KalmanFilter *kalmanFilter, Point2f pos); //2个卡尔曼初始化

	vector<Mat> Interacting();								//交互（只针对IMM算法）
	vector<Mat> predict_kalman(KalmanFilter *kalmanFilter); //2个卡尔曼预测

	void correct_kalman(KalmanFilter *kalmanFilter, Point2f pos); //2个卡尔曼矫正
	mix_model Model_mix(vector<kalman_XP> XP);					  //模型综合
	void Model_P_up(vector<kalman_eS> eS);						  //模型概率更新

	void kalman_imm_parameter(KalmanFilter *kalmanFilter); //在KF.correct之后使用
public:
	imm();
	void imm_kalman_init(KalmanFilter *kalmanFilter, Point2f pos); //imm,kalman初始化
	Mat imm_predict(KalmanFilter *kalmanFilter, bool truepre);				   //imm模型预测
	void imm_correct(KalmanFilter *kalmanFilter, Point2f pos);	 //imm模型矫正
	Point2f mix_model_point();
};

#include "Utility/Params.h"
#include "HardWareDriver/RmSerial.h"

RmSerial::RmSerial() {}

RmSerial::RmSerial(int PortNum, int BiteSpeed, int PortMode, char DataBits, char ParityBits, char StopBits) : m_PortNum(PortNum), m_BiteSpeed(BiteSpeed), m_PortMode(PortMode), m_DataBits(DataBits), m_ParityBits(ParityBits), m_StopBits(StopBits)
{
	InitPort();
};

RmSerial::~RmSerial()
{
	ClosePort();
}

bool RmSerial::InitPort()
{
	int speed_arr[] = {B921600, B460800, B230400, B115200, B57600, B38400, B19200, B9600, B4800, B2400, B1200, B300};
	int name_arr[] = {921600, 460800, 230400, 115200, 57600, 38400, 19200, 9600, 4800, 2400, 1200, 300};
	//ClosePort();
	if (!OpenPort())
		return false;
	termios tOption;
	if (tcgetattr(m_PortID, &tOption) != 0)
	{
		cerr << "ERROR: SetUp Serial Error\n";
		return false;
	}
	bzero(&tOption, sizeof(tOption));

	tOption.c_cflag |= CLOCAL | CREAD;
	tOption.c_cflag &= ~CSIZE;

	switch (m_DataBits)
	{
	case 7:
		tOption.c_cflag |= CS7;
		break;
	case 8:
		tOption.c_cflag |= CS8;
		break;
	default:
		tOption.c_cflag |= CS8;
		break;
	}

	switch (m_ParityBits)
	{
	case 'O':
	case 'o':
		tOption.c_cflag |= PARENB;
		tOption.c_cflag |= PARODD;
		tOption.c_iflag |= INPCK;
		break;
	case 'E':
	case 'e':
		tOption.c_cflag |= PARENB;
		tOption.c_cflag &= ~PARODD;
		break;
	case 'N':
	case 'n':
		tOption.c_cflag &= ~PARENB;
		tOption.c_iflag &= ~INPCK;
		break;
	default:
		tOption.c_cflag &= ~PARENB;
		tOption.c_iflag &= ~INPCK;
		break;
	}

	for (int i = 0; i < sizeof(name_arr) / sizeof(int); i++)
	{
		if (name_arr[i] == m_BiteSpeed)
		{
			tcflush(m_PortID, TCIOFLUSH);
			cfsetispeed(&tOption, speed_arr[i]);
			cfsetospeed(&tOption, speed_arr[i]);
			break;
		}
	}

	if (m_StopBits == 1)
		tOption.c_cflag &= ~CSTOPB;
	else if (m_StopBits == 2)
		tOption.c_cflag |= CSTOPB;

	tOption.c_cc[VTIME] = 1;
	tOption.c_cc[VMIN] = 1;

	tOption.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
	tOption.c_oflag &= ~OPOST;

	tcflush(m_PortID, TCIFLUSH);

	if ((tcsetattr(m_PortID, TCSANOW, &tOption)) != 0)
	{
		cerr << "ERROR: SetUp Serial Error\n";
		return false;
	}
	return true;
}

bool RmSerial::OpenPort()
{
	char PortStr[20];
	switch (m_PortMode)
	{
	case 0:
		sprintf(PortStr, "/dev/ttyUSB%d", m_PortNum);
		cout << "PortStr" <<PortStr<< endl;
		m_PortID = open(PortStr, O_RDWR);
		break;
	case 1:
		sprintf(PortStr, "/dev/ttyTHS%d", m_PortNum);
		m_PortID = open(PortStr, O_RDWR);
		break;
	default:
		sprintf(PortStr, "/dev/ttyUSB%d", m_PortNum);
		m_PortID = open(PortStr, O_RDWR);
		break;
	}
	cout << "m_PortMode" <<m_PortMode<< endl;
	if (m_PortID == -1)
	{
		cerr << "ERROR: Open Serial Error\n";
		if(m_PortNum==0)
		{
			m_PortNum=1;
		}
		else
		{
			m_PortNum=0;
		}
		return false;
	}
	else
		return true;
}

bool RmSerial::ClosePort()
{
	if (close(m_PortID) == -1)
	{
		cerr << "ERROR: Close Setial Error\n";
		return false;
	}
	else
		return true;
}

bool RmSerial::ReadData(unsigned char *dataGet, int dataLength)
{
	//memset(dataGet,0,sizeof(dataGet));
	if (m_PortID == -1)
	{
		cerr << "ERROR: Serial Call Error\n";
		InitPort();
		return false;
	}
	else if (dataGet == NULL)
	{
		cerr << "ERROR: DataGet Can't Be NULL\n";
		InitPort();
		return false;
	}

	if (read(m_PortID, dataGet, dataLength) == -1)
	{
		cerr << "ERROR: Read Error\n";
		InitPort();
		return false;
	}
	else
	{
		//tcflush(m_PortID, TCIFLUSH);
		return true;
	}
}
bool RmSerial::WriteData(unsigned char *dataSet, int dataLength)
{
	if (m_PortID == -1)
	{
		cerr << "ERROR: Serial Call Error\n";
		InitPort();
		cerr << "InitPort\n";
		return false;
	}
	else if (dataSet == NULL)
	{
		cerr << "ERROR: DataSet Can't Be NULL\n";
		InitPort();
		cerr << "InitPort\n";
		return false;
	}

	if (write(m_PortID, dataSet, dataLength) == -1)
	{
		cerr << "ERROR: Write Error\n";
		InitPort();
		cerr << "InitPort\n";
		return false;
	}
	else
	{
		//tcflush(m_PortID, TCOFLUSH);
		return true;
	}
}

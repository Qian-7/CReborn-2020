#include "HardWareDriver/HTCap.h"

//摄像头内参矩阵
Mat HTMatrix_640x480 = (Mat_<float>(3, 3) << 1317.31919518516, -0.0699970361395382, 313.763017388624,
											  0, 1317.52666123363, 220.704222540692, 
											  0, 0, 1);
Mat HTMatrix_1280x1024 = (Mat_<float>(3, 3) <<  1317.31919518516, -0.0699970361395382, 313.763017388624,
												0, 1317.52666123363, 220.704222540692, 
												0, 0, 1);
//摄像头畸变矩阵
Mat HTcoeMat_640x480 = (Mat_<float>(5, 1) << -0.391229567811804, 0.190689105470377, 0.000180179281372071, 0.000428837597150858, 0);
Mat HTcoeMat_1280x1024 = (Mat_<float>(5, 1) << -0.391229567811804, 0.190689105470377, 0.000180179281372071, 0.000428837597150858, 0);

HTCap::HTCap(int cap_Speedmode, bool auto_Exp, Size frameSize, int cap_expTime)
{	
	m_autoExp = auto_Exp;
	m_capExpTime = cap_expTime;
	m_frameSize = frameSize;
	m_capSpeed = cap_Speedmode;
	CameraSdkInit(1);
}

HTCap::~HTCap()
{
	HTuninit();
}

int HTCap::HTinit()
{
	//枚举设备，并建立设备列表
    iStatus = CameraEnumerateDevice(&tCameraEnumList,&iCameraCounts);
	printf("state = %d\n", iStatus);

	printf("count = %d\n", iCameraCounts);
    //没有连接设备
    if(iCameraCounts==0){
        return -1;
    }

    //相机初始化。初始化成功后，才能调用任何其他相机相关的操作接口
    iStatus = CameraInit(&tCameraEnumList,-1,-1,&hCamera);

    //初始化失败
	printf("state = %d\n", iStatus);
    if(iStatus!=CAMERA_STATUS_SUCCESS){
        return -1;
    }

    //获得相机的特性描述结构体。该结构体中包含了相机可设置的各种参数的范围信息。决定了相关函数的参数
    CameraGetCapability(hCamera,&tCapability);

    //
    g_pRgbBuffer = (unsigned char*)malloc(tCapability.sResolutionRange.iHeightMax*tCapability.sResolutionRange.iWidthMax*3);
    //g_readBuf = (unsigned char*)malloc(tCapability.sResolutionRange.iHeightMax*tCapability.sResolutionRange.iWidthMax*3);

	return 0;
}

int HTCap::HTuninit()
{
	CameraUnInit(hCamera);
	//注意，现反初始化后再free
    free(g_pRgbBuffer);
}

int HTCap::setAll()
{
	int si = setVideoSize(m_frameSize);
	setVideoFormat(m_frameSize);
	int ex = setExposureTime(m_autoExp, m_capExpTime);
	int sp = setVideoSpeed(m_capSpeed);

    if(tCapability.sIspCapacity.bMonoSensor){
        channel=1;
        CameraSetIspOutFormat(hCamera,CAMERA_MEDIA_TYPE_MONO8);
    }else{
        channel=3;
        CameraSetIspOutFormat(hCamera,CAMERA_MEDIA_TYPE_BGR8);
    }

	if(abs(si) + abs(ex) + abs(sp) == 0)
	{
		CameraPlay(hCamera);
		return 0;
	}
	else
		return -1;
}

int HTCap::setVideoSize(Size frameSize)
{
	CameraGetImageResolution(hCamera, &pImgRes);
	if(frameSize == Size(640, 480))
		pImgRes.iIndex = 1;
	else if(frameSize == Size(1280, 1024))
		pImgRes.iIndex = 0;
	else
		return -1;
	return CameraSetImageResolution(hCamera, &pImgRes);
}

int HTCap::setExposureTime(bool auto_exp, int expt)
{
	if(CameraSetAeState(hCamera,auto_exp) == 0)
		if(auto_exp == 0)
			return CameraSetExposureTime(hCamera, expt*1000);
	else
		return -1;
}


int HTCap::setVideoSpeed(int speedmode)
{
	if(speedmode == 0 || speedmode == 1)
		return CameraSetFrameSpeed(hCamera,speedmode);
	else
		return -1;
}

int HTCap::setVideoFormat(Size frameSize)
{
	if(frameSize.width == 640 && frameSize.height == 480)
	{
		m_Matrix = HTMatrix_640x480;
		m_coeMat = HTcoeMat_640x480;
	}
	else if(frameSize.width == 1280 && frameSize.height == 1024)
	{
		m_Matrix = HTMatrix_1280x1024;
		m_coeMat = HTcoeMat_1280x1024;
	}
	return 0;
}

int HTCap::startCap()
{
	return CameraPlay(hCamera);
}


int HTCap::pauseCap()
{
	return CameraPause(hCamera);
}

int HTCap::stopCap()
{
	return CameraStop(hCamera);
}

int HTCap::getWidth()
{
	return m_frameSize.width;
}

int HTCap::getHeight()
{
	return m_frameSize.height;
}

Size HTCap::getVideoSize()
{
	return m_frameSize;
}

int HTCap::getCapMatrix(Mat& matrix,Mat& coeMat)
{
	matrix = m_Matrix.clone();
	coeMat = m_coeMat.clone();
	return 0;
}

HTCap &HTCap::operator>>(cv::Mat &image)
{
	
	if(CameraGetImageBuffer(hCamera,&sFrameInfo,&pbyBuffer,1000) == CAMERA_STATUS_SUCCESS)
	{
		CameraImageProcess(hCamera, pbyBuffer, g_pRgbBuffer,&sFrameInfo);
		    
		cv::Mat matImage(
				Size(sFrameInfo.iWidth,sFrameInfo.iHeight), 
				sFrameInfo.uiMediaType == CAMERA_MEDIA_TYPE_MONO8 ? CV_8UC1 : CV_8UC3,
				g_pRgbBuffer
				);
		image = matImage;
		//在成功调用CameraGetImageBuffer后，必须调用CameraReleaseImageBuffer来释放获得的buffer。
		//否则再次调用CameraGetImageBuffer时，程序将被挂起一直阻塞，直到其他线程中调用CameraReleaseImageBuffer来释放了buffer
		CameraReleaseImageBuffer(hCamera,pbyBuffer);
		++cur_frame;
	}
}







































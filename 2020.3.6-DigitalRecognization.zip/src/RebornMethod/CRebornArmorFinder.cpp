﻿#include "RebornMethod/CRebornArmorFinder.h"
#include"EnemyClass/CLightBlobs.h"

//-------------------CRebornArmourFinder 设置--------------------------
String defaultWeightsPath = "../config/armourDlModel.pb";
String defaultPrototxtPath = "../config/armourDlModel.pbtxt";

String defaultSvmPath = "../config/svmModel.xml";
const char *ArmourClassNames[] = { "background", "armor" };

double angleMin = 30;

double minXdis_MaxHeight = 1;
double maxXdis_MaxHeight = 12;

double kThresh = 2; //0.5;
double hBThresh = 2; //1.7;
double disAgThresh = 90;// 12.85;
double yDisThresh = 2.00;//0.45;
double xDisThresh = 6.00;
double avgThresh = 20.00;
double bigThresh1 = 3.2;
double bigThresh2 = 5.0;
double smallThresh1 = 2.0;
double smallThresh2 = 3.1;

float distance(Point2f center, Point2f point)
{
	float x1 = center.x;
	float x2 = point.x;
	float y1 = center.y;
	float y2 = point.y;
	float dis_ = sqrt(pow(abs(x1 - x2), 2) + pow(abs(y1 - y2), 2));
	return dis_;
}


CRebornArmourFinder::CRebornArmourFinder(bool ifAimRed, int mode, String svmPath, String weightsPath, String prototxt) : m_ifAimRed(ifAimRed) //0 nomal | 1 svm | 2 dl
{
	m_mode = mode;
	svm_digital = SVM::load("svm.xml");
	switch (mode)
	{
	case 0:
		m_mode = RM_ARMOUR_NORMAL;
		break;
	case 1:
		m_mode = RM_ARMOUR_ML;
		InitSvm(svmPath);
		break;
	case 2:
		m_mode = RM_ARMOUR_DL;
		InitNet(weightsPath, prototxt);
		break;
	default:
		m_mode = RM_ARMOUR_NORMAL;
		break;
	}
}

CRebornArmourFinder::~CRebornArmourFinder() {}

void CRebornArmourFinder::InitSvm(String svmPath)
{
	m_model = SVM::load(svmPath);
}

void CRebornArmourFinder::InitNet(String weightsPath, String prototxt)
{
	m_net = cv::dnn::readNetFromTensorflow(weightsPath, prototxt);
}

vector<CArmour> CRebornArmourFinder::FindArmour(Mat srcImg)
{
	// switch (m_mode)
	// {
	// case RM_ARMOUR_NORMAL:
		return FindByNormal(srcImg);
	// case RM_ARMOUR_ML:
	// 	return FindByMl(srcImg);
	// case RM_ARMOUR_DL:
	// 	return FindByDl(srcImg);
	// default:
	// 	return FindByNormal(srcImg);
	// }
}


vector<CArmour> CRebornArmourFinder::FindByNormal(Mat srcImg)
{
	Mat rectImg = srcImg.clone();
	Mat lightImg = srcImg.clone();
	Mat armourImg = srcImg.clone();

	vector<Rect> hueRectVector;
	vector<RotatedRect> brightRotatedRectVector;
	vector<BrightLight> brightRectVector;
	vector<CArmour> armourVector;
	//vector<LightBlob> LightBlobs;
	LightBlobs LightBlob;

	if (!FindHueRoi(srcImg, hueRectVector))
	{
		resize(rectImg, rectImg, Size(320, 240));
		resize(lightImg, lightImg, Size(320, 240));
		resize(armourImg, armourImg, Size(320, 240));
		imshow("rectImg", rectImg);
		imshow("lightImg", lightImg);
		imshow("armourImg", armourImg);
		return armourVector;
	}

	if( !findLightBlobs(srcImg, LightBlob))
	{
		resize(rectImg, rectImg, Size(320, 240));
		resize(lightImg, lightImg, Size(320, 240));
		resize(armourImg, armourImg, Size(320, 240));
		imshow("rectImg", rectImg);
		imshow("lightImg", lightImg);
		imshow("armourImg", armourImg);
		return armourVector;
		
	}

	vector<CArmour> aimVector = SetPairLights(srcImg, LightBlob);

	for(int i = 0;i < aimVector.size();i++)
	{
		aimVector[i].DigitalRecognization(srcImg, svm_digital);
	}

	//aimVector = beatMirror(aimVector);
	for (int i = 0; i < hueRectVector.size(); i++)
	{
		rectangle(rectImg, hueRectVector[i], Scalar(0, 255, 0), 2);
	}

	/*for (int i = 0; i < brightRotatedRectVector.size(); i++)
	{
		DrawRotatedRect(lightImg, brightRotatedRectVector[i]);
	}*/

	for (int i = 0; i < brightRectVector.size(); i++)
	{
		DrawRotatedRect(lightImg, brightRectVector[i].minarearect);
	}
	
	for (int i = 0; i < aimVector.size(); i++)
	{
		aimVector[i].Show(armourImg);
	}
	resize(rectImg, rectImg, Size(320, 240));
	resize(lightImg, lightImg, Size(320, 240));
	resize(armourImg, armourImg, Size(320, 240));

	imshow("rectImg", rectImg);
	imshow("lightImg", lightImg);
	imshow("armourImg", armourImg);

	waitKey(30);
	return aimVector;
}


bool CRebornArmourFinder::FindHueRoi(Mat srcImg, vector<Rect> &hueRectVector)
{

	Mat frame; //待处理图像
	float ScaleOfWidth = srcImg.cols / 640.0f;
	float ScaleOfHeight = srcImg.rows / 480.0f;

	resize(srcImg, frame, Size(srcImg.cols / 2, srcImg.rows / 2)); //缩小图像分辨率，降低处理时间

	Mat threshImg;
	vector<Mat> splitImg;   //三颜色通道图像
	
	split(frame, splitImg); //颜色空间分离

	if (m_ifAimRed)
		threshImg = splitImg[2] - splitImg[1] - 3;//
	else
		threshImg = splitImg[0] - splitImg[1] - 3;//
	Mat avgImg = threshImg.clone();

	threshImg -= 20;
	int otsuNum = threshold(threshImg, threshImg, 0, 255, THRESH_OTSU);

	Mat element = getStructuringElement(MORPH_RECT, Size(4, 4));
	morphologyEx(threshImg, threshImg, MORPH_DILATE, element);
	vector<vector<Point>> contours; //轮廓
	vector<Vec4i> hierarchy;
	findContours(threshImg, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE);

	for (vector<vector<Point>>::iterator it = contours.begin(); it != contours.end(); it++)
	{
		if (contourArea(*it) <= 3) //舍弃面积过小矩形
			continue;
		Rect hueRect = boundingRect(*it);
		if (hueRect.area() >= 20 && GetAvgOfRoi(avgImg, hueRect, 1) > 5 && hueRect.width / ScaleOfWidth < hueRect.height / ScaleOfHeight * 1.1)
		{
			hueRect.x *= 2;
			hueRect.y *= 2;
			hueRect.height *= 2;
			hueRect.width *= 2;
			hueRect = hueRect + Point(-hueRect.width * 0.15f, -hueRect.height * 0.20f);
			hueRect = hueRect + Size(hueRect.width * 0.3f, hueRect.height * 0.40f);
			if (!MakeRectInLimit(hueRect, srcImg)) //防止矩形区域越界
				continue;
			hueRectVector.push_back(hueRect);
		}
	}

	if (hueRectVector.size() >= 25 || hueRectVector.size() == 0)
		return false;

	sort(hueRectVector.begin(), hueRectVector.end(), RectAreaSort); //将矩形有面积从小到大排序

	return true;
}



vector<CArmour> CRebornArmourFinder::SetPairLights(Mat srcImg, LightBlobs &LightBlobs)
//vector<CArmour> CRebornArmourFinder::SetPairLights(Mat srcImg, vector<BrightLight> &brightlightVector)
{
	vector<CArmour> armourVector;
	Mat reImg = srcImg.clone();
	//    for (vector<RotatedRect>::iterator it = brightRotatedRectVector.begin(); it != brightRotatedRectVector.end(); it++)
	//    {
	//        DrawRotatedRect(reImg, *it);
	//        cout<<(*it).angle<<"    ";
	//    }
	//    cout<<"=====================Rotated Angle========================="<<endl;
	for (vector<LightBlob>::iterator it = LightBlobs.begin(); it <= LightBlobs.end() - 1; it++)
	{
		/*if ((*it).ifPaired == 1)
			continue;*/
		for (vector<LightBlob>::iterator th = it + 1; th != LightBlobs.end(); th++)
		{
			/*if ((*th).ifPaired == 1)
				continue;*/
			float xdis, ydis, dis;
			float angle_left, angle_right;
			float avgAngle, disAngle;
			float minHeight, maxHeight;
			float heightBite;
			float k;
			float bili;

			xdis = fabs((*th).rect.center.x - (*it).rect.center.x);
			ydis = fabs((*th).rect.center.y - (*it).rect.center.y);
			dis = distance((*it).rect.center, (*th).rect.center);
			cout << "dis" << dis << endl;
			if (xdis < minXdis_MaxHeight * ((*it).rect.size.height))
				continue;
			else if (xdis >= maxXdis_MaxHeight * ((*it).rect.size.height))
				break;

			Rect mlRect = (*it).rect.boundingRect() | (*th).rect.boundingRect();
			if (mlRect.width / (float)mlRect.height < 1.0 || mlRect.width / (float)mlRect.height > 5)//0.8 8
				continue;
			angle_left = (*it).rect.angle;
			angle_right = (*th).rect.angle;

			avgAngle = fabsf(angle_left + angle_right) / 2;
			disAngle = fabsf(angle_left - angle_right);
			cout << "disAngle" << disAngle << endl;

			minHeight = min((*it).rect.size.height, (*th).rect.size.height);
			maxHeight = max((*it).rect.size.height, (*th).rect.size.height);
		// cout << "maxHeight" << maxHeight << endl;

			bili = dis / maxHeight;
		// cout << "bili" << bili << endl;

			if (minHeight == 0)
				continue;
			else
				heightBite = (float)maxHeight / minHeight;

			if (xdis == 0)
				continue;
			else
				k = fabsf(ydis / xdis);
	// cout << "NOMRAL NUM:  " << (k < kThresh) << " " << (heightBite < hBThresh) << " " << (disAngle < disAgThresh) << " " << (ydis < yDisThresh * maxHeight) << " " << (xdis < xDisThresh * minHeight) << " " << (avgAngle < avgThresh) << endl;
			if (k < kThresh && heightBite < hBThresh && disAngle < disAgThresh && ydis < yDisThresh * maxHeight && xdis < xDisThresh * minHeight && avgAngle < avgThresh)
			{
				if (xdis > 20 && xdis < 250 && bili < 4.1)
				{
					CArmour armour(*it, *th);
					if (dis >= bigThresh1 * maxHeight && dis <= bigThresh2 * maxHeight)
						armour.m_ifSmallArmour = false;
					else if (dis >= smallThresh1 * maxHeight && dis <= smallThresh2 * maxHeight)
						armour.m_ifSmallArmour = true;
					else
						continue;
					cout << "m_ifSmallArmour" << armour.m_ifSmallArmour << endl;
					/*(*it).ifPaired = 1; (*th).ifPaired = 1;*/
					armourVector.push_back(armour);
				}

			}
		}
	}
	return armourVector;
}
vector<CArmour> CRebornArmourFinder::beatMirror(vector<CArmour> armourVector)
{
	vector<CArmour> trueArmours;
	if (armourVector.size() < 2)
		return armourVector;
	else
	{
		sort(armourVector.begin(), armourVector.end(), sortOfX);
		for (int i = 0; i < armourVector.size() - 1;)
		{
			if (fabs(armourVector[i].m_ArmourCenter.x - armourVector[i + 1].m_ArmourCenter.x) <= fabs(armourVector[i].m_ArmourLeftLight.center.x - armourVector[i].m_ArmourRightLight.center.x))
			{
				if (armourVector[i].m_ArmourCenter.y < armourVector[i + 1].m_ArmourCenter.y)
				{
					trueArmours.push_back(armourVector[i]);
				}
				else
					trueArmours.push_back(armourVector[i + 1]);
				i += 2;
			}
			else
			{
				trueArmours.push_back(armourVector[i]);
				i++;
			}
		}
		if (armourVector.size() > 2 && fabs(armourVector[armourVector.size() - 1].m_ArmourCenter.x - armourVector[armourVector.size()].m_ArmourCenter.x) >= fabs(armourVector[armourVector.size() - 1].m_ArmourLeftLight.center.x - armourVector[armourVector.size() - 1].m_ArmourRightLight.center.x))
			trueArmours.push_back(armourVector[armourVector.size()]);
	}
	return trueArmours;
}

float CRebornArmourFinder::GetAvgOfRoi(Mat srcImg, Rect rect, int threshNum)
{
	Mat avgImg = srcImg(rect);
	return mean(avgImg, avgImg > threshNum)[0];
}

void CRebornArmourFinder::DrawRotatedRect(Mat srcImg, RotatedRect roRect)
{
	Point2f points[4];
	roRect.points(points);
	for (int i = 0; i < 4; i++)
	{
		line(srcImg, points[i], points[(i + 1) % 4], Scalar(255, 255, 255), 2, LINE_AA);
	}
}

bool sortOfX(CArmour X, CArmour Y)
{
	return X.m_ArmourCenter.x > Y.m_ArmourCenter.x;
}

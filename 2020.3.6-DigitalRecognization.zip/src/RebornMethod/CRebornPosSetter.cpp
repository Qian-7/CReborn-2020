﻿#include "RebornMethod/CRebornPosSetter.h"

Mat m_SmallArmorMessage = (Mat_<Point3f>(1, 4) << Point3f(-SMALL_WIG, -SMALL_HEI, 0.0),
						   Point3f(-SMALL_WIG, SMALL_HEI, 0.0),
						   Point3f(SMALL_WIG, SMALL_HEI, 0.0),
						   Point3f(SMALL_WIG, -SMALL_HEI, 0.0)); //小装甲板实际信息

Mat m_BigArmorMessage = (Mat_<Point3f>(1, 4) << Point3f(-BIG_WIG, -BIG_HEI, 0.0),
						 Point3f(-BIG_WIG, BIG_HEI, 0.0),
						 Point3f(BIG_WIG, BIG_HEI, 0.0),
						 Point3f(BIG_WIG, -BIG_HEI, 0.0)); //大装甲实际信息

double m_SmallKNum = 1000;
double m_BigKNum = 1000;

CRebornPostSetter::CRebornPostSetter() {}

CRebornPostSetter::~CRebornPostSetter() {}


vector<CArmour> CRebornPostSetter::SetArmourPos(vector<CArmour> ArmourVector, bool ifPnp)
{
	vector<CArmour> TrueArmourVector;
	for (int i = 0; i < ArmourVector.size(); i++)
	{
		SolvePnpPos(ArmourVector[i]);
		if ((ArmourVector[i]).m_ArmourPos.y > 10 && (ArmourVector[i]).m_ArmourPos.y < 2500)
			TrueArmourVector.push_back(ArmourVector[i]);
	}
	// cout<<"			Ture:"<<TrueArmourVector.size()<<endl;
	return TrueArmourVector;
}


bool CRebornPostSetter::SolvePnpPos(CArmour &Armour)
{
	Mat Matrix = (Mat_<float>(3,3) << 
										1317.31919518516,-0.0699970361395382,313.763017388624,
										0,1317.763017388624,220.704222540692,
										0,0,1);
	Mat coeMat = (Mat_<float>(5,1) << 	
										-0.391229567811804,
										0.190689195470377,
										0.000180179281372071,
										0.000428837597150858,
										0);
	int Cap_Width = 640;
	int Cap_Height = 480;
	

	Mat tvec = (Mat_<float>(3, 1));
	Mat rvec = (Mat_<float>(3, 1));
	Mat Rvec, rotMat;
	Mat_<float> Tvec;

	vector<Point2f> abc = Armour.GetPnpPoints(1);

	if (Armour.m_ifSmallArmour == true){
		solvePnP(m_SmallArmorMessage, abc, Matrix, coeMat, rvec, tvec, 1, 5);	
	}
		
	else{
		solvePnP(m_BigArmorMessage, Armour.GetPnpPoints(1), Matrix, coeMat, rvec, tvec, 0, 0);
	}

	tvec.convertTo(Tvec, CV_32F);
	Armour.m_ArmourPos = Point3f(Tvec(0, 0), -Tvec(2, 0), Tvec(1, 0));

	rvec.convertTo(Rvec, CV_32F);
	Rodrigues(Rvec, rotMat);
	float theta_X, theta_Y, theta_Z;
	theta_X = atan2(rotMat.at<float>(2, 1), rotMat.at<float>(2, 2));
	theta_Y = atan2(-rotMat.at<float>(2, 0), sqrt(rotMat.at<float>(2, 1) * rotMat.at<float>(2, 1) + rotMat.at<float>(2, 2) * rotMat.at<float>(2, 2)));
	theta_Z = atan2(rotMat.at<float>(1, 0), rotMat.at<float>(0, 0));

	theta_X = theta_X * (180 / CV_PI);
	theta_Y = theta_Y * (180 / CV_PI);
	theta_Z = theta_Z * (180 / CV_PI);

	Armour.m_ArmourAttitudeAngle = Point3f(fabs(theta_X), fabs(theta_Y), fabs(theta_Z));

	if (Tvec(2, 0) < 5 || Tvec(2, 0) > 1200)
		return false;
	else
		return true;
}


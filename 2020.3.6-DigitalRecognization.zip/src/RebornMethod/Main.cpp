#include<iostream>
#include<thread>
#include"RebornMethod/MultiThread.h"

using namespace std;
using namespace cv;

int main()
{
	MultiThread MultiThread;
	

	thread task0(&MultiThread::ImageProducter, ref(MultiThread));

	thread task1(&MultiThread::ImageConsumer, ref(MultiThread));

	thread task2(&MultiThread::SolveAngle, ref(MultiThread));


	task0.join();
	task1.join();
	task2.join();

	
	return 0;
}


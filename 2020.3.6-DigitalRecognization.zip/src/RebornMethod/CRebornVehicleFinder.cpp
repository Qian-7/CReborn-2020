﻿#include "RebornMethod/CRebornVehicleFinder.h"
//------------------CRebornVehicleFinder 设置---------------
String defaultVehicleWeightsPath = "../config/vehicleDlModel.pb";
String defaultVehiclePrototxt = "../config/vehicleDlModel.pbtxt";

CRebornVehicleFinder::CRebornVehicleFinder(String weightsPath, String prototxt)
{
	InitNet(weightsPath, prototxt);
}

CRebornVehicleFinder::~CRebornVehicleFinder() {}

void CRebornVehicleFinder::InitNet(String weightsPath, String prototxt)
{
	m_Net = cv::dnn::readNetFromTensorflow(weightsPath, prototxt);
}

vector<CVehicle> CRebornVehicleFinder::VehicleFind(Mat srcImg)
{
	vector<CVehicle> VehicleVector;
	Mat VehicleImg;
	resize(srcImg, VehicleImg, Size(300, 300));
	Mat blob = dnn::blobFromImage(VehicleImg, 1, Size(300, 300), Scalar(), true, true);
	m_Net.setInput(blob);
	Mat output = m_Net.forward();

	Mat detectionMat(output.size[2], output.size[3], CV_32F, output.ptr<float>());
	float confidenceThreshold = 0.60f;
	for (int i = 0; i < detectionMat.rows; i++)
	{
		float confidence = detectionMat.at<float>(i, 2);

		if (confidence > confidenceThreshold)
		{
			size_t objectClass = (size_t)(detectionMat.at<float>(i, 1));

			int xLeftBottom = static_cast<int>(detectionMat.at<float>(i, 3) * srcImg.cols);
			int yLeftBottom = static_cast<int>(detectionMat.at<float>(i, 4) * srcImg.rows);
			int xRightTop = static_cast<int>(detectionMat.at<float>(i, 5) * srcImg.cols);
			int yRightTop = static_cast<int>(detectionMat.at<float>(i, 6) * srcImg.rows);

			//int xLeftBottom = static_cast<int>(detectionMat.at<float>(i, 3) * VehicleImg.cols);
			//int yLeftBottom = static_cast<int>(detectionMat.at<float>(i, 4) * VehicleImg.rows);
			//int xRightTop = static_cast<int>(detectionMat.at<float>(i, 5) * VehicleImg.cols);
			//int yRightTop = static_cast<int>(detectionMat.at<float>(i, 6) * VehicleImg.rows);
			ostringstream ss;
			ss << confidence;
			String conf(ss.str());
			//Rect vehicleRect(Point((int)xLeftBottom, (int)yLeftBottom), Point((int)(xRightTop - xLeftBottom), (int)(yRightTop - yLeftBottom)));
			Rect vehicleRect(Point((int)xLeftBottom, (int)yLeftBottom), Point((int)(xRightTop), (int)(yRightTop)));
			if (!MakeRectInLimit(vehicleRect, srcImg))
				continue;
			if (vehicleRect.width <= srcImg.cols * 0.02 || vehicleRect.height <= srcImg.cols * 0.02 ||
				vehicleRect.width >= srcImg.cols * 0.85 || vehicleRect.height >= srcImg.rows * 0.85)
				continue;
			CVehicle Vehicle(vehicleRect, 1);
			VehicleVector.push_back(Vehicle);
		}
	}
	return VehicleVector;
}

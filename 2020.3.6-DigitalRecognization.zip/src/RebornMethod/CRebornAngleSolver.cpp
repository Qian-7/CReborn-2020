﻿#include "RebornMethod/CRebornAngleSolver.h"


//------------------CRebornAngleSolver  设置-------------------
float Tx = 0;	//以Yaw轴为原点，Pitch轴与枪管焦点为坐标的X值
float Ty = 0;	//以Yaw轴为原点，Pitch轴与枪管焦点为坐标的Y值
float Tz = 0; //以Yaw轴为原点，Pitch轴与枪管焦点为坐标的Z值-9.6
float Gx = -5.0; //以Pitch轴与枪管焦点为原点，摄像头坐标的X值
float Gy = 28.3;  //以Pitch轴与枪管焦点为原点，摄像头坐标的Y值  14.707   20.707
float Gz = 5.18;  //以Pitch轴与枪管焦点为原点，摄像头坐标的Z值   4.98
float errx = 0 * CV_PI / 180.0;//以Pitch轴与枪管焦点为原点，摄像头坐标的Z值1.3 
//子弹弹速(单位 m/s)
float lowSpeed = 14.0f;
float highSpeed = 23.0f;

//ofstream outf;

CRebornAngleSolver::CRebornAngleSolver()
{
	// InitDebugFrame();
}

CRebornAngleSolver::~CRebornAngleSolver()
{
	clear();
}

bool CRebornAngleSolver::SolveArmourAngle(vector<CArmour> ArmourVector, float Angle_Yaw, float Angle_Pitch)
{
	clear();
	// InitDebugFrame();
	SetGunAngle(Angle_Yaw, Angle_Pitch);
	GetM(); //    ********
	if (ArmourVector.size() > 0)
	{
		ConvertArmourToWorldPos(ArmourVector);
		filter();
		Point3f PYD;
		if (m_IfHighSpeed == 1)
			PYD = SolvePitchYaw(m_Predict_target.x, m_Predict_target.y, m_Predict_target.z, highSpeed);
		else
			PYD = SolvePitchYaw(m_Predict_target.x, m_Predict_target.y, m_Predict_target.z, lowSpeed);		

		//PYD.x -= m_GunPitchIn * 180.0 / CV_PI;
		//PYD.y -= m_GunYawIn * 180.0 / CV_PI;
		m_PitchAngleOut = PYD.x;
		m_YawAngleOut = PYD.y;
		m_DisTance = PYD.z;
	}
	else
	{
		filter();
		Point3f PYD;
		if (m_IfHighSpeed == 1)
			PYD = SolvePitchYaw(m_Predict_target.x, m_Predict_target.y, m_Predict_target.z, highSpeed);
		else
			PYD = SolvePitchYaw(m_Predict_target.x, m_Predict_target.y, m_Predict_target.z, lowSpeed);

		m_PitchAngleOut = PYD.x;
		m_YawAngleOut = PYD.y;
		m_DisTance = PYD.z;
	}
	return m_IfOutNum;
}


void CRebornAngleSolver::SetGunAngle(float Yaw, float Pitch)
{
	m_GunPitchIn = Pitch * CV_PI / 180.0;
	//Yaw += 6;
	m_GunYawIn = -Yaw * CV_PI / 180.0;
}

void CRebornAngleSolver::GetM() //    ********
{
	M = (Mat_<float>(4, 4) << cos(m_GunYawIn), cos(m_GunPitchIn) * sin(m_GunYawIn), -sin(m_GunYawIn) * sin(m_GunPitchIn), Gx * cos(m_GunYawIn) + Tx * cos(m_GunYawIn) + Ty * sin(m_GunYawIn) + Gy * cos(m_GunPitchIn) * sin(m_GunYawIn) - Gz * sin(m_GunYawIn) * sin(m_GunPitchIn),
		 -sin(m_GunYawIn), cos(m_GunYawIn) * cos(m_GunPitchIn), -cos(m_GunYawIn) * sin(m_GunPitchIn), Ty * cos(m_GunYawIn) - Gx * sin(m_GunYawIn) - Tx * sin(m_GunYawIn) + Gy * cos(m_GunYawIn) * cos(m_GunPitchIn) - Gz * cos(m_GunYawIn) * sin(m_GunPitchIn),
		 0, sin(m_GunPitchIn), cos(m_GunPitchIn), Tz + Gz * cos(m_GunPitchIn) + Gy * sin(m_GunPitchIn),
		 0, 0, 0, 1);
}

void CRebornAngleSolver::ConvertArmourToWorldPos(vector<CArmour> ArmourVector)
{
	//vector<float> angle;
	float min = 0.5 * CV_PI;
	//int inc = 0;
	for (vector<CArmour>::iterator it = ArmourVector.begin(); it != ArmourVector.end(); it++)
	{
		Point3f Pos = (*it).m_ArmourPos;
		Point3f LeftLightPos = (*it).m_ArmourLeftPos;
		Point3f RightLightPos = (*it).m_ArmourRightPos;
		Mat post = (Mat_<float>(4, 1) << Pos.x, Pos.y, Pos.z, 1); 
		Mat post_L = (Mat_<float>(4, 1) << LeftLightPos.x, LeftLightPos.y, LeftLightPos.z, 1); 
		Mat post_R = (Mat_<float>(4, 1) << RightLightPos.x, RightLightPos.y, RightLightPos.z, 1); 
		Mat XYZ, XYZ_L, XYZ_R;
		if (!(abs(Pos.x) < 0.01 && abs(Pos.y) < 0.01 && abs(Pos.z) < 0.01)) //    ********
		{
			float temp_y, temp_p, temp_dis;
			double temp_angle;
			Point3f CworldPos, LworldPos, RworldPos;
			Point2f floorPos;
		
			XYZ = M * post;
			XYZ_L = M * post_L;
			XYZ_R = M * post_R;
			CworldPos = Point3f(XYZ.at<float>(0), XYZ.at<float>(1), XYZ.at<float>(2));
			LworldPos = Point3f(XYZ_L.at<float>(0), XYZ_L.at<float>(1), XYZ_L.at<float>(2));
			RworldPos = Point3f(XYZ_R.at<float>(0), XYZ_R.at<float>(1), XYZ_R.at<float>(2));
		

			m_worldCenter.push_back(CworldPos);
			m_worldLeftLight.push_back(LworldPos);
			m_worldRightLight.push_back(RworldPos);

			// circle(m_DebugFrame, Point2f(CworldPos.x * 0.6, CworldPos.y * 0.6) + Point2f(400, 400), 5, Scalar(0, 0, 255), -1);
			// circle(m_DebugFrame, Point2f(LworldPos.x * 0.6, LworldPos.y * 0.6) + Point2f(400, 400), 2, Scalar(255, 0, 0), -1);
			// circle(m_DebugFrame, Point2f(RworldPos.x * 0.6, RworldPos.y * 0.6) + Point2f(400, 400), 2, Scalar(0, 255, 0), -1);
			// line(m_DebugFrame, Point2f(LworldPos.x * 0.6, LworldPos.y * 0.6) + Point2f(400, 400), Point2f(RworldPos.x * 0.6, RworldPos.y * 0.6) + Point2f(400, 400), Scalar(0, 155, 155), 2);
			floorPos.x = CworldPos.x;
			floorPos.y = CworldPos.y;
			m_armorCenter.push_back(floorPos);

			Mat Lights = (Mat_<double>(2, 1) << LworldPos.x-RworldPos.x, LworldPos.y-RworldPos.y);
			Mat Center = (Mat_<double>(2, 1) << CworldPos.x, CworldPos.y);
			normalize(Lights,Lights,1,0,NORM_L2);
			normalize(Center,Center,1,0,NORM_L2);
// cout<<"Center:"<<Center<<"Lights:"<<Lights<<endl;

			double temp_A = Center.dot(Lights);
			temp_angle = acos(temp_A)*180.0/CV_PI;
			m_armorAngle.push_back(temp_angle);

			temp_y = atan2(post.at<float>(0), post.at<float>(1));
			if (abs(temp_y) < min)
			{
				min = abs(temp_y);
				m_NearestCarPoint = floorPos;
			}
		}
	}
}

void CRebornAngleSolver::filter()
{
	m_Predict.comprehensive(m_worldCenter, m_NearestCarPoint, m_armorAngle);
	m_IfOutNum = m_Predict.have_Newobservetrack;
// cout << "m_IfOutNum" << m_IfOutNum <<endl;
	if (m_Predict.have_Newobservetrack)
	{
		if (m_IfHero)
		{
			m_Predict_target = m_Predict.ture_hit_predict_kalman();
		}
		else
		{
			m_Predict_target = m_Predict.ture_hit_predict_kalman();
			//cout << "bubing" <<endl;
		}
		// cout << "predict_target:" << m_Predict_target << endl;

		// circle(m_DebugFrame, Point2f(m_Predict_target.x * 0.6, m_Predict_target.y * 0.6) + Point2f(400, 400), 5, Scalar(255, 255, 255), -1);
	}
	// imshow("m_floorPoint", m_DebugFrame);
}

Point3f CRebornAngleSolver::SolvePitchYaw(float Pos_X, float Pos_Y, float Pos_Z, float Speed)
{
	double y_meter = (sqrt(Pos_Y * Pos_Y + Pos_X * Pos_X)) / 100.0;
	double z_add = y_meter*1.82-2.0036;

	double z_meter = (Pos_Z - Tz + z_add) / 100.0;
	
	double PitchOut = atan2(z_meter, y_meter) * 180.0 / CV_PI;
	
	double YawOut = atan2(Pos_X, Pos_Y) * 180.0 / CV_PI;
	
	float DisTance = z_meter * 10.0;
	return Point3f(PitchOut, YawOut, DisTance);
}
double CRebornAngleSolver::solveParabolaAngle(double aimPos_x, double aimPos_y, double v, int iteration_times)
{
	double temp_y = aimPos_y;
	double tempAngle, parabola_angle, v_x, v_y, t, tarGet_y, dif_y;
	//double airDrag_num = 0.1; //空气阻力系数
	for (size_t i = 0; i < iteration_times; ++i)
	{
		tempAngle = solveLinearAngle(aimPos_x, temp_y);
		v_x = v * cos(tempAngle);
		v_y = v * sin(tempAngle);
		t = airDrag_t(aimPos_x, v_x, AIRDRAG_NUM);
		tarGet_y = gravity_distance(v_y, G, t);
		dif_y = aimPos_y - tarGet_y;
		temp_y = temp_y + dif_y;
	}
	parabola_angle = tempAngle / (CV_PI)*180.0;
	return parabola_angle;
}
double CRebornAngleSolver::solveLinearAngle(double aimPos_x, double aimPos_y)
{
	double linearAngle = atan(aimPos_y / aimPos_x);
	return linearAngle;
}
double CRebornAngleSolver::airDrag_t(double C, double p, double S, double pos_x, double v_x, double m)
{
	double k1 = C * p * S / (2 * m);
	double fly_time = (exp(pos_x * k1) - 1) / (k1 * v_x);
	return fly_time;
}
double CRebornAngleSolver::airDrag_t(double pos_x, double v_x, double airDrag_num)
{
	double fly_time = (exp(pos_x * airDrag_num) - 1) / (airDrag_num * v_x);
	return fly_time;
}
double CRebornAngleSolver::gravity_distance(double v_y, double g, double t)
{
	double fall_dist = v_y * t - 0.5 * g * pow(t, 2);
	return fall_dist;
}

void CRebornAngleSolver::InitDebugFrame()
{
	// m_DebugFrame = Mat::zeros(Size(800, 800), CV_32FC3);
}

void CRebornAngleSolver::clear()
{
	m_worldCenter.clear();
	m_armorCenter.clear();
	m_armorAngle.clear();
	m_worldLeftLight.clear();
	m_worldRightLight.clear();
}

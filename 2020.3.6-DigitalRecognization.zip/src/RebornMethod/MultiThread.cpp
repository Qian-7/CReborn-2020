#include "RebornMethod/MultiThread.h"

	int framecount = 0;

	using namespace std;
	using namespace cv;

	//product requirement document Idx
	volatile int prdIdx = 0;
	//Customer Service Management Idx
	volatile int csmIdx = 0;





	void MultiThread::ImageProducter() {
		
		VideoCapture capture("a1.avi");
		Mat src;




double time0 = getTickCount();

		/////////////��ѭ��//////////////////////
		while (true) {

// double Time = getTickCount();			


			capture >> src;

			if(src.empty()) 
				waitKey(0);

			imshow("srcimg",src);
			
			
						
			mtx.lock();
			src.copyTo(rsFrame);
			prdIdx = 1;
			mtx.unlock();

			sleep(1.5);
			

// Time = (getTickCount() - Time) / (getTickFrequency() / 1000);
// cout << "Time1: " << Time << "ms" << endl;
		}
	}




	void MultiThread::ImageConsumer() {

		Mat src;

		CRebornArmourFinder armourHunter;
		
		vector<CArmour> armourVector;


		//////////////////////////��ѭ��/////////////////////////////
		while (true) {
double Time = getTickCount();	
			mtx.lock();
			while (prdIdx == 0);
			rsFrame.copyTo(src);
			mtx.unlock();

			armourVector = armourHunter.FindArmour(src);	
			
			mtxx.lock();
			vArmour = armourVector;
			csmIdx = 1;
			mtxx.unlock();

Time = (getTickCount() - Time) / (getTickFrequency() / 1000);
cout << "Time2					@@@@@: " << Time << "ms" << endl;
		}

	}



	void MultiThread::SolveAngle() {

		
		CRebornPostSetter postHunter;
		CRebornAngleSolver angleHunter;
		float solveAngle_P = 1, solveAngle_Y = 1;
		unsigned char Str_Write[8];
		vector<CArmour> armourVector;

		while(true){

double Time = getTickCount();	
			while(csmIdx == 0);

			mtxx.lock();
			armourVector = vArmour;
			mtxx.unlock();

			armourVector = postHunter.SetArmourPos(armourVector, 1);
			angleHunter.SolveArmourAngle(armourVector, solveAngle_Y, solveAngle_P);
			
		
Time = (getTickCount() - Time) / (getTickFrequency() / 1000);
// cout << "Time3			$$$$$ " << Time << "ms" << endl;
		}
	}



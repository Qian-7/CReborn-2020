#include "CRebornBoost/xml.h"
#include "CRebornBoost/stereo.h"

//static float terraceX = -14.0f;
//static float terraceY = 24.7f;
//static float terraceZ = -5.9f;
//static float Pitch = -2.5*CV_PI/180.0;//1.5
//static float Yaw = 0.9*CV_PI/180.0;


void Stereo::stereo_init()
{
	XML xml;
	xml.read_map_yml(Q);
	Q.convertTo(Q, CV_32FC1);
	cout << Q << endl;
	xml.read_map_yml(mapLx_inv, mapLy_inv, mapRx_inv, mapRy_inv);
	//xml.read_map_yml(validROIL, validROIR);
	//ML = (Mat_<float>(4, 4) << 	cos(Yaw), cos(Pitch)*sin(Yaw), sin(Yaw)*sin(Pitch), terraceX, \
					-sin(Yaw), cos(Yaw)*cos(Pitch), sin(Pitch)*cos(Yaw), terraceY,\
					0, -sin(Pitch), cos(Pitch), terraceZ,\
					0, 0, 0, 1);
	//cout<<"-=-=-=-=-=-="<<ML<<endl;
}

void Stereo::SetGunAngle(float Yaw, float Pitch)
{
	m_GunPitchIn = Pitch * CV_PI / 180.0;
	//Yaw += 6;
	m_GunYawIn = Yaw * CV_PI / 180.0;
}

void Stereo::Get_ML()
{
float Tx = 0;	//��Yaw��Ϊԭ�㣬Pitch����ǹ�ܽ���Ϊ�����Xֵ
float Ty = 0;	//��Yaw��Ϊԭ�㣬Pitch����ǹ�ܽ���Ϊ�����Yֵ
float Tz = 14.0; //��Yaw��Ϊԭ�㣬Pitch����ǹ�ܽ���Ϊ�����Zֵ
float Gx = -3.0; //��Pitch����ǹ�ܽ���Ϊԭ�㣬����ͷ�����Xֵ
float Gy = 5.7;  //��Pitch����ǹ�ܽ���Ϊԭ�㣬����ͷ�����Yֵ
float Gz = 5.5;  //��Pitch����ǹ�ܽ���Ϊԭ�㣬����ͷ�����Zֵ

	ML = (Mat_<float>(4, 4) << cos(m_GunYawIn), cos(m_GunPitchIn) * sin(m_GunYawIn), -sin(m_GunYawIn) * sin(m_GunPitchIn), Gx * cos(m_GunYawIn) + Tx * cos(m_GunYawIn) + Ty * sin(m_GunYawIn) + Gy * cos(m_GunPitchIn) * sin(m_GunYawIn) - Gz * sin(m_GunYawIn) * sin(m_GunPitchIn),
		-sin(m_GunYawIn), cos(m_GunYawIn) * cos(m_GunPitchIn), -cos(m_GunYawIn) * sin(m_GunPitchIn), Ty * cos(m_GunYawIn) - Gx * sin(m_GunYawIn) - Tx * sin(m_GunYawIn) + Gy * cos(m_GunYawIn) * cos(m_GunPitchIn) - Gz * cos(m_GunYawIn) * sin(m_GunPitchIn),
		0, sin(m_GunPitchIn), cos(m_GunPitchIn), Tz + Gz * cos(m_GunPitchIn) + Gy * sin(m_GunPitchIn),
		0, 0, 0, 1);
}

void Stereo::rectification(vector<Point2f> Left, vector<Point2f> Right)
{
	if (Left_.size() > 0)
		Left_.clear();
	if (Right_.size() > 0)
		Right_.clear();
	//cout <<"rectification0"<<endl;
	if (matchedPoints.size() > 0)
		matchedPoints.clear();
	if (coordinates3D.size() > 0)
		coordinates3D.clear();
	//cout <<"rectification1"<<endl;

	for (int i = 0; i < Left.size(); i++)
	{
		int floor_Ly = cvFloor(Left[i].y);
		int floor_Lx = cvFloor(Left[i].x);

		float bias_x = Left[i].x - (float)floor_Lx;
		float bias_y = Left[i].y - (float)floor_Ly;

		float Px = bias_x * mapLx_inv.at<float>(floor_Ly, floor_Lx + 1) + (1 - bias_x)* mapLx_inv.at<float>(floor_Ly, floor_Lx);
		float Py = bias_y * mapLy_inv.at<float>(floor_Ly + 1, floor_Lx) + (1 - bias_y)* mapLy_inv.at<float>(floor_Ly, floor_Lx);

		cout << "Left_" << Point2f(Px, Py) << endl;
		Left_.push_back(Point2f(Px, Py));
	}
	//cout <<"rectification2"<<endl;
	for (int i = 0; i < Right.size(); i++)
	{
		int floor_Ry = cvFloor(Right[i].y);
		int floor_Rx = cvFloor(Right[i].x);

		float bias_x = Right[i].x - (float)floor_Rx;
		float bias_y = Right[i].y - (float)floor_Ry;

		float Px = bias_x * mapRx_inv.at<float>(floor_Ry, floor_Rx + 1) + (1 - bias_x)* mapRx_inv.at<float>(floor_Ry, floor_Rx);
		float Py = bias_y * mapRy_inv.at<float>(floor_Ry + 1, floor_Rx) + (1 - bias_y)* mapRy_inv.at<float>(floor_Ry, floor_Rx);
		cout << "Right_" << Point2f(Px, Py) << endl;
		Right_.push_back(Point2f(Px, Py));
	}
}

void Stereo::rectification(vector<Point2f> L_c, vector<Point2f> R_c, vector<Point2f> L_L, vector<Point2f> R_L, vector<Point2f> L_R, vector<Point2f> R_R)
{
	if (Left_.size() > 0)
		Left_.clear();
	if (Right_.size() > 0)
		Right_.clear();
	if (Left_L.size() > 0)
		Left_L.clear();
	if (Right_L.size() > 0)
		Right_L.clear();
	if (Left_R.size() > 0)
		Left_R.clear();
	if (Right_R.size() > 0)
		Right_R.clear();

	if (matchedPoints.size() > 0)
		matchedPoints.clear();
	if (coordinates3D.size() > 0)
		coordinates3D.clear();
	if (LeftLight3D.size() > 0)
		LeftLight3D.clear();
	if (RightLight3D.size() > 0)
		RightLight3D.clear();

	for (int i = 0; i < L_c.size(); i++)
	{
		int floor_Ly = cvFloor(L_c[i].y);
		int floor_Lx = cvFloor(L_c[i].x);

		float bias_x = L_c[i].x - (float)floor_Lx;
		float bias_y = L_c[i].y - (float)floor_Ly;

		float Px = bias_x * mapLx_inv.at<float>(floor_Ly, floor_Lx + 1) + (1 - bias_x)* mapLx_inv.at<float>(floor_Ly, floor_Lx);
		float Py = bias_y * mapLy_inv.at<float>(floor_Ly + 1, floor_Lx) + (1 - bias_y)* mapLy_inv.at<float>(floor_Ly, floor_Lx);

		cout << "Left_:" << Point2f(Px, Py) << " ";
		Left_.push_back(Point2f(Px, Py));
	}
	cout << endl;
	//cout <<"rectification2"<<endl;
	for (int i = 0; i < R_c.size(); i++)
	{
		int floor_Ry = cvFloor(R_c[i].y);
		int floor_Rx = cvFloor(R_c[i].x);

		float bias_x = R_c[i].x - (float)floor_Rx;
		float bias_y = R_c[i].y - (float)floor_Ry;

		float Px = bias_x * mapRx_inv.at<float>(floor_Ry, floor_Rx + 1) + (1 - bias_x)* mapRx_inv.at<float>(floor_Ry, floor_Rx);
		float Py = bias_y * mapRy_inv.at<float>(floor_Ry + 1, floor_Rx) + (1 - bias_y)* mapRy_inv.at<float>(floor_Ry, floor_Rx);
		cout << "Right_:" << Point2f(Px, Py) << " ";
		Right_.push_back(Point2f(Px, Py));
	}
	cout << endl;
	for (int i = 0; i < L_L.size(); i++)
	{
		int floor_Ly = cvFloor(L_L[i].y);
		int floor_Lx = cvFloor(L_L[i].x);

		float bias_x = L_L[i].x - (float)floor_Lx;
		float bias_y = L_L[i].y - (float)floor_Ly;

		float Px = bias_x * mapLx_inv.at<float>(floor_Ly, floor_Lx + 1) + (1 - bias_x)* mapLx_inv.at<float>(floor_Ly, floor_Lx);
		float Py = bias_y * mapLy_inv.at<float>(floor_Ly + 1, floor_Lx) + (1 - bias_y)* mapLy_inv.at<float>(floor_Ly, floor_Lx);

		cout << "Left_L" << Point2f(Px, Py) << " ";
		Left_L.push_back(Point2f(Px, Py));
	}
	cout << endl;
	//cout <<"rectification2"<<endl;
	for (int i = 0; i < R_L.size(); i++)
	{
		int floor_Ry = cvFloor(R_L[i].y);
		int floor_Rx = cvFloor(R_L[i].x);

		float bias_x = R_L[i].x - (float)floor_Rx;
		float bias_y = R_L[i].y - (float)floor_Ry;

		float Px = bias_x * mapRx_inv.at<float>(floor_Ry, floor_Rx + 1) + (1 - bias_x)* mapRx_inv.at<float>(floor_Ry, floor_Rx);
		float Py = bias_y * mapRy_inv.at<float>(floor_Ry + 1, floor_Rx) + (1 - bias_y)* mapRy_inv.at<float>(floor_Ry, floor_Rx);
		cout << "Right_L" << Point2f(Px, Py) << " ";
		Right_L.push_back(Point2f(Px, Py));
	}
	cout << endl;
	for (int i = 0; i < L_R.size(); i++)
	{
		int floor_Ly = cvFloor(L_R[i].y);
		int floor_Lx = cvFloor(L_R[i].x);

		float bias_x = L_R[i].x - (float)floor_Lx;
		float bias_y = L_R[i].y - (float)floor_Ly;

		float Px = bias_x * mapLx_inv.at<float>(floor_Ly, floor_Lx + 1) + (1 - bias_x)* mapLx_inv.at<float>(floor_Ly, floor_Lx);
		float Py = bias_y * mapLy_inv.at<float>(floor_Ly + 1, floor_Lx) + (1 - bias_y)* mapLy_inv.at<float>(floor_Ly, floor_Lx);

		cout << "Left_R" << Point2f(Px, Py) << " ";
		Left_R.push_back(Point2f(Px, Py));
	}
	cout << endl;
	//cout <<"rectification2"<<endl;
	for (int i = 0; i < R_R.size(); i++)
	{
		int floor_Ry = cvFloor(R_R[i].y);
		int floor_Rx = cvFloor(R_R[i].x);

		float bias_x = R_R[i].x - (float)floor_Rx;
		float bias_y = R_R[i].y - (float)floor_Ry;

		float Px = bias_x * mapRx_inv.at<float>(floor_Ry, floor_Rx + 1) + (1 - bias_x)* mapRx_inv.at<float>(floor_Ry, floor_Rx);
		float Py = bias_y * mapRy_inv.at<float>(floor_Ry + 1, floor_Rx) + (1 - bias_y)* mapRy_inv.at<float>(floor_Ry, floor_Rx);
		cout << "Right_R" << Point2f(Px, Py) << " ";
		Right_R.push_back(Point2f(Px, Py));
	}
	cout << endl;
}
void Stereo::getCompare()
{
	for (int i = 0; i < Left_.size(); i++)
	{
		for (int j = 0; j < Right_.size(); j++)
		{
			if (abs(Left_[i].y - Right_[j].y) < 6)
			{
				if (Left_[i].x - Right_[j].x > 0 && Left_[i].x - Right_[j].x < Parallax)
				{
					Matched newMatched{
						Left_[i],Right_[j],Left_L[i],Right_L[j],Left_R[i],Right_R[j]
					};
					matchedPoints.push_back(newMatched);
				}
			}
		}
	}
}

void Stereo::solve3Dcoordinate()
{
	for (int i = 0; i < matchedPoints.size(); i++)
	{
		float x_l = matchedPoints[i].LeftPoint.x;
		float x_r = matchedPoints[i].RightPoint.x;
		float y = matchedPoints[i].LeftPoint.y;
		float d = x_l - x_r;
		Mat   xyd1 = (Mat_<float>(4, 1) << x_l, y, d, 1.0);
		Mat_<float> XYZW = Q * xyd1;
		float X = XYZW.at<float>(0);
		float Y = XYZW.at<float>(1);
		float Z = XYZW.at<float>(2);
		float W = XYZW.at<float>(3);
		//cout << X << " " << Y << " " << Z << " " << W << endl;
		Point3f world = Point3f((X / W) / 10.0, (Y / W) / 10.0, (Z / W) / 10.0);
		cout << "world" << world << endl;
		coordinates3D.push_back(world);

		x_l = matchedPoints[i].L_LPoint.x;
		x_r = matchedPoints[i].R_LPoint.x;
		y = matchedPoints[i].L_LPoint.y;
		d = x_l - x_r;
		xyd1 = (Mat_<float>(4, 1) << x_l, y, d, 1.0);
		XYZW = Q * xyd1;
		X = XYZW.at<float>(0);
		Y = XYZW.at<float>(1);
		Z = XYZW.at<float>(2);
		W = XYZW.at<float>(3);
		//cout << X << " " << Y << " " << Z << " " << W << endl;
		world = Point3f((X / W) / 10.0, (Y / W) / 10.0, (Z / W) / 10.0);
		cout << "LeftLight" << world << endl;
		LeftLight3D.push_back(world);

		x_l = matchedPoints[i].L_RPoint.x;
		x_r = matchedPoints[i].R_RPoint.x;
		y = matchedPoints[i].L_RPoint.y;
		d = x_l - x_r;
		xyd1 = (Mat_<float>(4, 1) << x_l, y, d, 1.0);
		XYZW = Q * xyd1;
		X = XYZW.at<float>(0);
		Y = XYZW.at<float>(1);
		Z = XYZW.at<float>(2);
		W = XYZW.at<float>(3);
		//cout << X << " " << Y << " " << Z << " " << W << endl;
		world = Point3f((X / W) / 10.0, (Y / W) / 10.0, (Z / W) / 10.0);
		cout << "RightLight" << world << endl;
		RightLight3D.push_back(world);
	}
}

vector<CArmour> Stereo::compute(vector<CArmour> ArmourVector)
{
	
	CArmour TrueArmour;
	vector<CArmour> TrueArmourVector;
	vector<Point2f> Left, Right;
	vector<Point2f> LeftL, RightL;
	vector<Point2f> LeftR, RightR;
	for (int i = 0; i < ArmourVector.size(); i++)
	{
		if (ArmourVector[i].m_ArmourCenter.x < 640)
		{
			Right.push_back(ArmourVector[i].m_ArmourCenter - Point2f(640, 0));
			RightL.push_back(ArmourVector[i].m_ArmourLeftLight.center - Point2f(640, 0));
			RightR.push_back(ArmourVector[i].m_ArmourRightLight.center - Point2f(640, 0));
		}
		else
		{
			Left.push_back(ArmourVector[i].m_ArmourCenter);
			LeftL.push_back(ArmourVector[i].m_ArmourLeftLight.center);
			LeftR.push_back(ArmourVector[i].m_ArmourRightLight.center);
		}
	}
	//cout <<"compute1"<<endl;
	//rectification(Left, Right);
	rectification(Left, Right, LeftL, RightL, LeftR, RightR);
	//cout <<"compute2"<<endl;
	getCompare();
	//cout <<"compute3"<<endl;
	solve3Dcoordinate();

	for (int i = 0; i < coordinates3D.size(); i++)
	{
		TrueArmour.m_ArmourPos = Point3f(coordinates3D[i].x, coordinates3D[i].z, -coordinates3D[i].y);
		TrueArmour.m_ArmourLeftPos = Point3f(LeftLight3D[i].x, LeftLight3D[i].z, -LeftLight3D[i].y);
		TrueArmour.m_ArmourRightPos = Point3f(RightLight3D[i].x, RightLight3D[i].z, -RightLight3D[i].y);
		TrueArmourVector.push_back(TrueArmour);
	}
	return TrueArmourVector;

}

//vector<Point3f> Stereo::GetPos()
//{
//
//}
void Stereo::ConvertCentralPos()
{
	Get_ML();
	for (int i = 0; i < coordinates3D.size(); i++)
	{
		Mat post = (Mat_<float>(4, 1) << coordinates3D[i].x, coordinates3D[i].z, -coordinates3D[i].y, 1), XYZ;
		XYZ = ML * post;
		coordinates3D[i].x = XYZ.at<float>(0);
		coordinates3D[i].y = XYZ.at<float>(1);
		coordinates3D[i].z = XYZ.at<float>(2);
	}
}

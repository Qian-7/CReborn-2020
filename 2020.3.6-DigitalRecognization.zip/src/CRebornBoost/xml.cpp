#include "CRebornBoost/xml.h"
#include "CRebornBoost/stereo.h"

void XML::write_cam_yml()
{
    FileStorage Cam("newCamera.yml", FileStorage::WRITE);
	//开始文件写入
	Mat cameraMatrixL = (Mat_<double>(3, 3) << 649.089159070446, -3.18760175075740, 317.658166856712,
		0, 652.666535693068, 246.005908583302,
		0, 0, 1);
	Mat distCoeffL = (Mat_<double>(5, 1) << 0.0155351620979218, -0.0216958880459308, 0.00225616054225846, -0.00128954245034745, 0.157611902520294);

	Mat cameraMatrixR = (Mat_<double>(3, 3) << 643.957621934819, -2.17508353098680, 310.962842537646,
		0, 646.989391996944, 261.241441631563,
		0, 0, 1);
	Mat distCoeffR = (Mat_<double>(5, 1) << 0.0265568278461992, -0.100905003086942, 0.00210702984939801, -0.00176891534319513, 0.141848412699641);

	Mat T = (Mat_<double>(3, 1) << -251.238470417023, -1.92211569812595, 0.362448193627107);//T平移向量(k1,k2,p1,p2,k3)
	//Mat rec = (Mat_<double>(3, 1) << -0.00306, -0.03207, 0.00206);//rec旋转向量
	Mat R = (Mat_<double>(3, 3) << 0.999889272823412, 0.0121909001602470, -0.00853370060118252,
		-0.0122899689439494, 0.999856553430379, -0.0116545796012293,
		0.00839039665477686, 0.0117581680379012, 0.999895667921593);//R 旋转矩阵

	Cam << "cameraMatrixL" << cameraMatrixL << "distCoeffL" << distCoeffL;
	Cam << "cameraMatrixR" << cameraMatrixR << "distCoeffR" << distCoeffR;
	Cam << "T" << T << "R" << R;
	Cam.release();

	printf("\n文件读写完毕，请在工程目录下查看生成的文件~");
}

void XML::write_map_yml()
{
	Mat cameraMatrixL, distCoeffL, cameraMatrixR, distCoeffR, T, rec, R;
	Mat Rl, Rr, Pl, Pr, Q; //校正旋转矩阵R，投影矩阵P 重投影矩阵Q
	Mat mapLx, mapLy, mapRx, mapRy;     //映射表 
	Mat mapLx_inv, mapLy_inv, mapRx_inv, mapRy_inv;     //映射表 
	Rect validROIL, validROIR;

    FileStorage Cam("/home/debug/Desktop/0607/Watcher/src/CRebornBoost/newCamera0.yml", FileStorage::READ);
    FileStorage Map("/home/debug/Desktop/0607/Watcher/src/CRebornBoost/newMap0.yml", FileStorage::WRITE);

	Cam["cameraMatrixL"] >> cameraMatrixL;
	Cam["distCoeffL"] >> distCoeffL;
	Cam["cameraMatrixR"] >> cameraMatrixR;
	Cam["distCoeffR"] >> distCoeffR;
	Cam["T"] >> T;
	//Cam["rec"] >> rec;
	Cam["R"] >> R;
	
	stereoRectify(cameraMatrixL, distCoeffL, cameraMatrixR, distCoeffR, imageSize, R.t(), T, Rl, Rr, Pl, Pr, Q, CALIB_ZERO_DISPARITY,
		1, imageSize, &validROIL, &validROIR);
	initUndistortRectifyMap(cameraMatrixL, distCoeffL, Rl, Pl, imageSize, CV_32FC1, mapLx, mapLy);
	initUndistortRectifyMap(cameraMatrixR, distCoeffR, Rr, Pr, imageSize, CV_32FC1, mapRx, mapRy);

	getlookuptable(mapLx, mapLy, mapLx_inv, mapLy_inv, 0);
	getlookuptable(mapRx, mapRy, mapRx_inv, mapRy_inv, 1);

	Map << "mapLx_inv" << mapLx_inv << "mapLy_inv" << mapLy_inv;
	//cout << mapLx.at<short int>(120, 160)[0] << endl;
	Map << "mapRx_inv" << mapRx_inv << "mapRy_inv" << mapRy_inv;
	Map << "validROIL" << validROIL << "validROIR" << validROIR;
	Map << "Q" << Q;
	
	Cam.release();
	Map.release();
}

void XML::read_map_yml(Mat &Q)
{
    FileStorage Map("/home/debug/Desktop/0607/Watcher/src/CRebornBoost/newMap0.yml", FileStorage::READ);
	Map["Q"] >> Q;
}


void XML::read_map_yml(Mat &mapLx, Mat &mapLy, Mat &mapRx, Mat &mapRy)
{
    FileStorage Map("/home/debug/Desktop/0607/Watcher/src/CRebornBoost/newMap0.yml", FileStorage::READ);

	Map["mapLx_inv"] >> mapLx;
	Map["mapLy_inv"] >> mapLy;
	Map["mapRx_inv"] >> mapRx;
	Map["mapRy_inv"] >> mapRy;
}

void XML::read_map_yml(Rect &validROIL, Rect &validROIR)
{
    FileStorage Map("newMap.yml", FileStorage::READ);

	Map["validROIL"] >> validROIL;
	Map["validROIR"] >> validROIR;
}

#include "CRebornBoost/xml.h"
#include "CRebornBoost/stereo.h"

using namespace cv;
using namespace std;

float distance_(Point center, Point2f point)
{
	float x1 = float(center.x);
	float x2 = point.x;
	float y1 = float(center.y);
	float y2 = point.y;
	float dis = sqrt(pow(abs(x1 - x2), 2) + pow(abs(y1 - y2), 2));
	return dis;
}

void XML::getlookuptable(Mat mapx, Mat mapy, Mat &mapx_inv, Mat &mapy_inv, bool type)//type: 0->L  1->R
{
	vector<Point2f> lookup;
	Mat_<Vec2f> LookUpTable(mapx.size());
	LookUpTable.setTo(-10);
	mapx_inv.create(Size(640, 480), mapx.type());
	mapy_inv.create(Size(640, 480), mapx.type());
	int weight = mapx.cols;
	int height = mapx.rows;
	int n = height / 480;
	for (int i = 0; i < height; i++)
	{
		for (int j = 0; j < weight; j++)
		{
			if (mapx.at<float>(i, j) >= -7.5 && mapy.at<float>(i, j) >= -7.5)
			{
				if (mapx.at<float>(i, j) <= 647.1 && mapy.at<float>(i, j) <= 487.1)
				{
					//lookup.push_back(Point2f(mapx.at<float>(i, j), mapy.at<float>(i, j)));
					LookUpTable.at<Vec2f>(i, j)[0] = mapx.at<float>(i, j);
					LookUpTable.at<Vec2f>(i, j)[1] = mapy.at<float>(i, j);
				}
			}
		}
	}
	//    109 + 2.484375*l         18 + 0.9515625*l
	//    249 + 2.4778*k           27 + 0.9395833*k
	for (int i = 0; i < 480; i++)
	{
		cout << "i:" << i << endl;
		for (int j = 0; j < 640; j++)
		{
			//cout << "  j:" << j ;
			//if (j == 625)
			//	waitKey(1);
			int tempj, tempi;
			if (type == false)
			{
				tempj = 18 + 0.9515625*(j - 3);
				tempi = 27 + 0.9395833*(i - 3);
			}
			else
			{

				tempj = 13 + 0.9546875*(j - 3);
				tempi = 1 + 0.95416667*(i - 3);
			}
			Point now(j, i);
			if (tempi < 0)
				tempi = 0;
			if (tempj < 0)
				tempj = 0;
			if ((tempi < 480 && tempi >= 0) && (tempj < 640 && tempj >= 0))
			{
				Point2f mindis = Point2f(LookUpTable.at<Vec2f>(tempi, tempj)[0],
					LookUpTable.at<Vec2f>(tempi, tempj)[1]);
				float dis_ = distance_(now, mindis);
				int min_k = 0, min_l = 0;
				for (int k = 0; k < 7 * 0.9395833; k++)
				{
					for (int l = 0; l < 7 * 0.9515625; l++)
					{
						if ((tempi + k) < 480 && (tempj + l) < 640)
						{
							Point2f temp = Point2f(LookUpTable.at<Vec2f>(int(tempi + k), int(tempj + l))[0],
								LookUpTable.at<Vec2f>(int(tempi + k), int(tempj + l))[1]);
							float now_dis = distance_(now, temp);
							if (now_dis < dis_)
							{
								mindis = temp;
								dis_ = now_dis;
								min_k = k;
								min_l = l;
							}
						}
					}
				}
				Point2f err = mindis - (Point2f)now;
				if (err.x > 0)
				{
					if (tempj + min_l - 1 >= 0)
					{
						float err1x = err.x;
						float err2x = (float)now.x - LookUpTable.at<Vec2f>((tempi + min_k), (tempj + min_l - 1))[0];
						float bias = err1x / (err1x + err2x);
						mapx_inv.at<float>(i, j) = ((float)(tempj + min_l) - bias) / (float)n;
					}
					else
					{
						mapx_inv.at<float>(i, j) = (float)(tempj + min_l) / (float)n;
					}
				}
				else
				{
					if (tempj + min_l + 1 < 640)
					{
						float err1x = err.x;
						float err2x = (float)now.x - LookUpTable.at<Vec2f>((tempi + min_k), (tempj + min_l + 1))[0];
						float bias = err1x / (err1x + err2x);
						mapx_inv.at<float>(i, j) = ((float)(tempj + min_l) + bias) / (float)n;
					}
					else
					{
						mapx_inv.at<float>(i, j) = (float)(tempj + min_l) / (float)n;
					}
				}
				if (err.y > 0)
				{
					if (tempi + min_k - 1 >= 0)
					{
						float err1y = err.y;
						float err2y = (float)now.y - LookUpTable.at<Vec2f>((tempi + min_k - 1), (tempj + min_l))[1];
						float bias = err1y / (err1y + err2y);
						mapy_inv.at<float>(i, j) = ((float)(tempi + min_k) - bias) / (float)n;
					}
					else
					{
						mapy_inv.at<float>(i, j) = (float)(tempi + min_k) / (float)n;
					}
				}
				else
				{
					if (tempi + min_k + 1 < 480)
					{
						float err1y = err.y;
						float err2y = (float)now.y - LookUpTable.at<Vec2f>((tempi + min_k + 1), (tempj + min_l))[1];
						float bias = err1y / (err1y + err2y);
						mapy_inv.at<float>(i, j) = ((float)(tempi + min_k) + bias) / (float)n;
					}
					else
					{
						mapy_inv.at<float>(i, j) = (float)(tempi + min_k) / (float)n;
					}
				}
			}
		}
	}
}

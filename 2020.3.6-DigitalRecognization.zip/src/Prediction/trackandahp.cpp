﻿#include "Prediction/trackandahp.h"


float distance_(Point2f center, Point2f point)
{
	float x1 = center.x;
	float x2 = point.x;
	float y1 = center.y;
	float y2 = point.y;
	float dis_ = sqrt(pow(abs(x1 - x2), 2) + pow(abs(y1 - y2), 2));
	return dis_;
}


void polynomial_curve_fit(vector<Point2f> key_point, int n, Mat& A)
{
	//Number of key points  
	int N = key_point.size();
	//构造矩阵X
	Mat X = Mat::zeros(n + 1, n + 1, CV_64FC1);
	for (int i = 0; i < n + 1; i++)
	{
		for (int j = 0; j < n + 1; j++)
		{
			for (int k = 0; k < N; k++)
			{
				X.at<double>(i, j) = X.at<double>(i, j) + pow(key_point[k].x, i + j);
			}
		}
	}
	//构造矩阵Y  
	Mat Y = Mat::zeros(n + 1, 1, CV_64FC1);
	for (int i = 0; i < n + 1; i++)
	{
		for (int k = 0; k < N; k++)
		{
			Y.at<double>(i, 0) = Y.at<double>(i, 0) + pow(key_point[k].x, i) * key_point[k].y;
		}
	}
	A = Mat::zeros(n + 1, 1, CV_64FC1);
	//参数A  
	solve(X, Y, A, DECOMP_LU);
	//return true;
}

void convert_timerelation(vector<Point2f> key_point, vector<Point2f> &V_x, vector<Point2f> &V_y)
{
	//Number of key points  
	int N = key_point.size();
	for (int i = 0; i < N; i++)
	{
		Point2f vx = Point2f(i*20, key_point[i].x);
		Point2f vy = Point2f(i*20, key_point[i].y);
		V_x.push_back(vx);
		V_y.push_back(vy);
	}
	
}

void copy_Track(Track *des, Track *source)
{

	//des->center = Point2d(source->center);
	des->car_distance = source->car_distance;
	des->height = source->height;
	des->consecutiveInvisibleCount = source->consecutiveInvisibleCount;
	des->_imm = source->_imm;
	des->trackcenters = source->trackcenters;
	KalmanFilter temp_filter[3],temp_height;

	temp_filter[0].transitionMatrix = source->KF[0].transitionMatrix.clone();
	source->KF[0].errorCovPost.copyTo(temp_filter[0].errorCovPost);
	source->KF[0].statePost.copyTo(temp_filter[0].statePost);
	source->KF[0].processNoiseCov.copyTo(temp_filter[0].processNoiseCov);
	//cout<<"temp_filter[0].statePost"<<temp_filter[0].statePost<<endl;

	temp_filter[1].transitionMatrix = source->KF[1].transitionMatrix.clone();
	source->KF[1].errorCovPost.copyTo(temp_filter[1].errorCovPost);
	source->KF[1].statePost.copyTo(temp_filter[1].statePost);
	source->KF[1].processNoiseCov.copyTo(temp_filter[1].processNoiseCov);
	//cout<<"temp_filter[1].statePost"<<temp_filter[1].statePost<<endl;

	temp_filter[2].transitionMatrix = source->KF[2].transitionMatrix.clone();
	source->KF[2].errorCovPost.copyTo(temp_filter[2].errorCovPost);
	source->KF[2].statePost.copyTo(temp_filter[2].statePost);
	source->KF[2].processNoiseCov.copyTo(temp_filter[2].processNoiseCov);
	//cout<<"temp_filter[1].statePost"<<temp_filter[2].statePost<<endl;

	//des->_imm.imm_kalman_init(temp_filter, des->center);
	//des->SmY = temp_height;
	des->KF[0] = temp_filter[0];
	des->KF[1] = temp_filter[1];
	des->KF[2] = temp_filter[2];
	//waitKey(1);
}


Point3f track_ahp::ture_hit_predict_kalman() //实际打击目标的卡尔曼预测
{
	Point3f predict;
	vector<Point2f> poly_x, poly_y;
	Mat Ax,Ay;
	Mat pre(6, 1, CV_32F);

	int times = 10;//int((Newobservetrack.car_distance / 2500) / T);//1;
	//cout<<"times:"<<times<<endl;

	if(unassignedTrack.size()>0 && Newobservetrack.consecutiveInvisibleCount>0)
		return Point3f(Newobservetrack.center.x, Newobservetrack.center.y, Newobservetrack.height);

	//convert_timerelation(Newobservetrack.trackcenters,poly_x,poly_y);
//for(int i=0;i<poly_x.size();i++)
//	cout<<"poly_x["<<i<<"]:"<<poly_x[i]<<" ";
//cout<<endl;
	//polynomial_curve_fit(poly_x,2,Ax);
	//polynomial_curve_fit(poly_y,2,Ay);
	pre = Scalar::all(0);
	for (int i = 0; i < (1+times); i++) 
	{
		pre = Newobservetrack._imm.imm_predict(Newobservetrack.KF,true);
		
	}

	//int t = 20*(times+poly_x.size()-1);
	//cout<<"t:"<<t<<endl;
	//cout<<"Ax:"<<Ax<<endl;
	//double x = Ax.at<double>(0, 0) + Ax.at<double>(1, 0) * t + Ax.at<double>(2, 0)*pow(t, 2);// + Ax.at<double>(3, 0)*pow(t, 3)
	//double y = Ay.at<double>(0, 0) + Ay.at<double>(1, 0) * t + Ay.at<double>(2, 0)*pow(t, 2);// + Ay.at<double>(3, 0)*pow(t, 3)
	//predict = Point3f(x, y, Newobservetrack.height);
	predict = Point3f(pre.at<float>(0), pre.at<float>(1), Newobservetrack.height);
	return predict;
}
/*
Point3f track_ahp::ture_hit_predict_kalman() //实际打击目标的卡尔曼预测
{
	Point3f predict;
	vector<Point2f> poly_x, poly_y;
	Mat Ax,Ay;
	Mat pre(6, 1, CV_32F);

	int times = 5;//int((Newobservetrack.car_distance / 2500) / T);//1;
	//cout<<"times:"<<times<<endl;

	//if(unassignedTrack.size()>0 && Newobservetrack.consecutiveInvisibleCount>0)
	//	return Point3f(Newobservetrack.center.x, Newobservetrack.center.y, Newobservetrack.height);

	convert_timerelation(Newobservetrack.trackcenters,poly_x,poly_y);
for(int i=0;i<poly_x.size();i++)
	cout<<"poly_x["<<i<<"]:"<<poly_x[i]<<" ";
cout<<endl;
	polynomial_curve_fit(poly_x,2,Ax);
	polynomial_curve_fit(poly_y,2,Ay);
	pre = Scalar::all(0);
	//for (int i = 0; i < (1+times); i++) 
	//{
	//	pre = Newobservetrack._imm.imm_predict(Newobservetrack.KF,true);
	//}

	int t = 20*(times+poly_x.size()-1);
	cout<<"t:"<<t<<endl;
	cout<<"Ax:"<<Ax<<endl;
	double x = Ax.at<double>(0, 0) + Ax.at<double>(1, 0) * t + Ax.at<double>(2, 0)*pow(t, 2);// + Ax.at<double>(3, 0)*pow(t, 3)
	double y = Ay.at<double>(0, 0) + Ay.at<double>(1, 0) * t + Ay.at<double>(2, 0)*pow(t, 2);// + Ay.at<double>(3, 0)*pow(t, 3)
	predict = Point3f(x, y, Newobservetrack.height);
	//predict = Point3f(pre.at<float>(0), pre.at<float>(1), Newobservetrack.height);
	return predict;
}*/

Point3f track_ahp::ture_hit_predict_kalman(int x = 1)
{
	Point3f predict;
	Mat pre(6, 1, CV_32F);//,preZ(2, 1, CV_32F);
	//int times = int((Newobservetrack.car_distance / 3000) / 0.02);
	//cout<<"times:"<<times<<endl;
	if(unassignedTrack.size()>0 && Newobservetrack.consecutiveInvisibleCount>0)
		return Point3f(Newobservetrack.center.x, Newobservetrack.center.y, Newobservetrack.height);
	pre = Scalar::all(0);
	for (int i = 0; i < (2); i++) 
	{
		pre = Newobservetrack._imm.imm_predict(Newobservetrack.KF,true);
		//preZ = Newobservetrack.SmY.predict();
	}

	predict = Point3f(pre.at<float>(0), pre.at<float>(1), Newobservetrack.height);
	return predict;
}


void track_ahp::getattribute(vector<Point3f> centers, Point2f m_preCel, vector<double> m_armorAngle) //, vector<int> car_type
{

// cout<<"centers.size():"<<centers.size()<<endl;
	for (int i = 0; i < centers.size(); i++)
	{
//cout << "centers["<<i<<"]:" << centers[i] << endl;
// cout << "m_armorAngle["<<i<<"]:" << m_armorAngle[i] << endl;
		Point2f temp = Point2f(centers[i].x, centers[i].y);
		centroids.push_back(temp);
		Angles.push_back(m_armorAngle[i]);
		heights.push_back(centers[i].z);
		if (!have_Newobservetrack)
			preCelectedpoint = m_preCel;
		//cartypes.push_back(car_type[i]);
		float distance = sqrt(pow(centers[i].x, 2) + pow(centers[i].y, 2));
		dis.push_back(distance);
	}
}


void track_ahp::predictNewLocationsOfTracks() //根据位置进行卡尔曼预测
{
	//cout<<"tracks.size():"<<tracks.size()<<endl;
	for (int i = 0; i < tracks.size(); i++)
	{
//cout<<"i:"<<i<<endl;
		Mat predict = tracks[i]._imm.imm_predict(tracks[i].KF,false);
		//Mat predictZ = tracks[i].SmY.predict();
//cout << "firstpre:" << predict << endl;
//cout << "predictZ:" << predictZ << endl;
		Point2f predictPt(predict.at<float>(0), predict.at<float>(1));
		tracks[i].center = predictPt;
//cout << "tracks[" << i << "].age" << tracks[i].age << endl;
	}
}


void track_ahp::detectionToTrackAssignment() //匈牙利算法匹配
{
	int nTracks = tracks.size();
	int nDetections = centroids.size();
//cout<<"nTracks"<<nTracks <<endl;
//cout<<"nDetections"<<nDetections <<endl;
	Mat cost(Size(nDetections, nTracks), CV_32FC1, Scalar(0));
	int costOfNonAssignment = 40;

	for (int i = 0; i < nTracks; i++)
	{
		for (int j = 0; j < nDetections; j++)
		{
			cost.at<float>(i, j) = distance_(tracks[i].center, centroids[j]);
			// cout<<"isnan"<<isnan(cost.at<float>(i, j))<<endl;;
			if(isnan(cost.at<float>(i, j)))
			{
				cost.at<float>(i, j)=100;
				//waitKey(0);
			}

			//else if(cost.at<float>(i, j)>100)
			//	cost.at<float>(i, j)=100;
		}
	}
// cout <<"cost:"<< cost << endl;
	if (nTracks != 0 && nDetections != 0)
		munkres(cost, costOfNonAssignment, assignments, unassignedTrack, unassignedDetection);

/*for(int i = 0;i<assignments.size();i++)
	cout << "assignments["<<i<<"}:" << assignments[i]<<endl;
for(int i = 0;i<unassignedTrack.size();i++)
	cout << "unassignedTrack["<<i<<"}:" << unassignedTrack[i]<<endl;
*/
	if (nTracks == 0 && nDetections != 0)
	{
//cout<<"nTracks == 0 && nDetections != 0"<<endl;
		for (int j = 0; j < nDetections; j++)
		{
			unassignedDetection.push_back(j);
		}
	}
	if (nTracks != 0 && nDetections == 0)
	{
		for (int j = 0; j < nTracks; j++)
		{
			//unassignedTrack.push_back(tracks[j].id);
			unassignedTrack.push_back(j);
//cout<<"nTracks != 0 && nDetections == 0"<<endl;
		}
	}
}


void track_ahp::updataAssignedTracks() //分配好的轨迹更新
{
	int detectionIdx;
	Point2f centroid;
	float height;
//cout<< "assignments.size()" << assignments.size() <<endl;
	for (int i = 0; i < assignments.size(); i++)
		if (assignments[i] != -1)
		{
			detectionIdx = assignments[i];
			centroid = centroids[detectionIdx];
			height = heights[detectionIdx];
//cout << "height:" << height <<endl;

			Mat measurement = Mat::zeros(1, 1, CV_32F);
			measurement.at<float>(0) = height;
//cout << "measurement:" << measurement <<endl;
			tracks[i]._imm.imm_correct(tracks[i].KF, centroid); //kalman矫正

			tracks[i].last_angle = tracks[i].now_angle;
			tracks[i].now_angle = Angles[detectionIdx];
			tracks[i].angle_v = (tracks[i].now_angle - tracks[i].last_angle)/T;
cout<<"tracks[i].now_angle:"<<tracks[i].now_angle<<endl;
cout<<"tracks[i].last_angle:"<<tracks[i].last_angle<<endl;
cout<<"tracks[i].angle_v:"<<tracks[i].angle_v<<endl;
			AngletrackV_Filter(&tracks[i]);

			if (tracks[i].age < 3)
			{
				tracks[i].center = centroid;
				tracks[i].height = height;
				
			}
			else
			{
				tracks[i].center = tracks[i]._imm.mix_model_point();
				if(distance_(tracks[i].center, centroid)>5)
				{
					tracks[i].center = centroid;
					tracks[i].KF[0].statePost.setTo(0); tracks[i].KF[0].statePost.at<float>(0, 0) = centroid.x; tracks[i].KF[0].statePost.at<float>(1, 0) = centroid.y;
					tracks[i].KF[0].statePre.setTo(0); tracks[i].KF[0].statePre.at<float>(0, 0) = centroid.x; tracks[i].KF[0].statePre.at<float>(1, 0) = centroid.y;
					tracks[i].KF[1].statePost.setTo(0); tracks[i].KF[1].statePost.at<float>(0, 0) = centroid.x; tracks[i].KF[1].statePost.at<float>(1, 0) = centroid.y;
					tracks[i].KF[1].statePre.setTo(0); tracks[i].KF[1].statePre.at<float>(0, 0) = centroid.x; tracks[i].KF[1].statePre.at<float>(1, 0) = centroid.y;
					tracks[i].KF[2].statePost.setTo(0); tracks[i].KF[2].statePost.at<float>(0, 0) = centroid.x; tracks[i].KF[2].statePost.at<float>(1, 0) = centroid.y;
					tracks[i].KF[2].statePre.setTo(0); tracks[i].KF[2].statePre.at<float>(0, 0) = centroid.x; tracks[i].KF[2].statePre.at<float>(1, 0) = centroid.y;
					
					
				}
				//tracks[i].height = tracks[i].SmY.statePost.at<float>(0);
				tracks[i].height = height;
				
			}
			tracks[i].trackcenters.push_back(tracks[i].center);
			if(tracks[i].trackcenters.size() > 4)
				tracks[i].trackcenters.erase(tracks[i].trackcenters.begin(), tracks[i].trackcenters.begin() + 1);

//cout << "tracks[i].height:" << tracks[i].height <<endl;;				
			//cout << "tracks[i].center:" << tracks[i].center << endl;
			
			cout << "滤波后: " << tracks[i].center << endl;
			tracks[i].car_distance = sqrt(pow(tracks[i].center.x, 2) + pow(tracks[i].center.y, 2)); //更新车辆距摄像头距离
			tracks[i].age++;					//更新轨迹年龄
			tracks[i].totalVisibleCount++;				//更新总可识别帧数
			tracks[i].consecutiveInvisibleCount = 0;		//清零连续不可识别帧数
		}
}


void track_ahp::updataUnassignedTracks() //未分配的轨迹更新
{
	int ind;
//cout<< "unassignedTrack.size()" << unassignedTrack.size() <<endl;
	for (int i = 0; i < unassignedTrack.size(); i++)
	{
		ind = unassignedTrack[i];

		for (int i = 0; i < tracks.size(); i++)
		{
			if (i == ind)
			{
				tracks[i].age++;					   //更新轨迹年龄
				tracks[i].consecutiveInvisibleCount++; //更新连续不可识别帧数
				tracks[i].last_angle = tracks[i].now_angle;
				tracks[i].now_angle = tracks[i].last_angle + tracks[i].f_angle_v * T;
				tracks[i].trackcenters.push_back(tracks[i].center);
				if(tracks[i].trackcenters.size() > 6)
					tracks[i].trackcenters.erase(tracks[i].trackcenters.begin(), tracks[i].trackcenters.begin() + 1);
				//cout << "UnassignedTracks: " << ind << endl;//*****
				//cout << "consecutiveInvisibleCount: " << tracks[i].consecutiveInvisibleCount << endl;//*****
			}
		}
	}
}


void track_ahp::deletedLostTracks() //删除丢失的轨迹
{
	if (tracks.size() != 0)
	{
		int invisibleForTooLong = 4;
		int ageThreshold = 6;
		//vector<int> ages, totalVisibleCounts;
		vector<Track>::iterator iter;
		for (iter = tracks.begin(); iter != tracks.end();)
		{
			int ages = (*iter).age;
			int totalVisibleCounts = (*iter).totalVisibleCount;
			float visibility = (float)totalVisibleCounts / ages;
			bool lostInds = (ages < ageThreshold && visibility < 0.6) || (ages >= ageThreshold && (*iter).consecutiveInvisibleCount >= invisibleForTooLong);
			if (lostInds)
			{
				iter = tracks.erase(iter);
				//cout << "del" << endl;
			}
			else
				iter++;
		}
	}
}


void track_ahp::createNewTracks() //创建新轨迹
{
	for (int i = 0; i < unassignedDetection.size(); i++)
	{
		int j = unassignedDetection[i];
		Point2f centroid = centroids[j];
		float height = heights[j];
		KalmanFilter kalmanFilter[3];//, SmoothingY
		double input[3] = {0.0,0.0,0.0};
		double output[3] = {0.0,0.0,0.0};
		vector<Point2f> trackcenters;
		trackcenters.push_back(centroid);
		Track newTrack{
			nextId, centroid, height, kalmanFilter[0], kalmanFilter[1], kalmanFilter[1], 1, 1, 0, dis[j], imm(), Angles[j], Angles[j], 0.0, 0.0, input[0], input[1], input[2], output[0], output[1], output[2], trackcenters
		};

		newTrack._imm.imm_kalman_init(kalmanFilter, centroid);
		newTrack.KF[0] = kalmanFilter[0];
		newTrack.KF[1] = kalmanFilter[1];
		newTrack.KF[2] = kalmanFilter[2];

		tracks.push_back(newTrack);
		nextId = nextId + 1;
		//appear_possible_newflag = 1;
	}
}
double filter_5HZ[3] = {1.1429805025399011, -0.41280159809618877, 0.06745527388907196};
void AngletrackV_Filter(Track *track_)
{
	track_->Input[0] = track_->Input[1];
	track_->Input[1] = track_->Input[2];
	track_->Input[2] = track_->angle_v * filter_5HZ[2];
	track_->Output[0] = track_->Output[1];
	track_->Output[1] = track_->Output[2];
	track_->Output[2] = (track_->Input[0]+track_->Input[2])+2*track_->Input[1]+(filter_5HZ[1]*track_->Output[0])+(filter_5HZ[0]*track_->Output[1]);
	track_->f_angle_v = track_->Output[2];
cout<<"f_angle_v:"<<track_->f_angle_v<<endl;	
}

void track_ahp::the_selected_target()
{
	if (tracks.size() >= 2)
	{
		float minDis = -1, minID = -1;

		float tar_minDis = 100, tar_minID = -1;
		Point2f target_point;
		for (int i = 0; i < centroids.size(); i++)
		{
			float temp_dis = distance_(centroids[i], preCelectedpoint);
			if (temp_dis < tar_minDis && temp_dis <=20)
			{
				tar_minDis = temp_dis;
				target_point = centroids[i];
				tar_minID = i;
			}
		}
		if(centroids.size() == 0)
		{
			target_point = preCelectedpoint;
		}
		if(tar_minID == -1)
		{
			target_point = preCelectedpoint;
		}
		for (int i = 0; i < tracks.size(); i++)
		{
			if (tracks[i].age >= 3)
			{
				minDis = distance_(tracks[i].center, target_point);
				minID = i;
				break;
			}
		}
		if (minDis != -1)
		{
			for (int i = 0; i < tracks.size(); i++)
			{
				if (tracks[i].age >= 3 && distance_(tracks[i].center, target_point) < minDis)
				{
					minDis = distance_(tracks[i].center, target_point);
					minID = i;
				}
			}
			double pretime = 3;
			double mdis = 80, mID = minID;
			if(abs((tracks[minID].now_angle+tracks[minID].f_angle_v*T*pretime)-90.)>55)
				for (int i = 0; i < tracks.size(); i++)
				{
					if (i != minID && tracks[i].age >= 3 && distance_(tracks[i].center, tracks[minID].center) < mdis)
					{
						mdis = distance_(tracks[i].center, tracks[minID].center);
						mID = i;
					}
				}
			
			copy_Track(&Newobservetrack, &tracks[mID]);
			preCelectedpoint = tracks[mID].center;
			have_Newobservetrack = 1;
		}
		else
		{
			have_Newobservetrack = 0;
		}
	}
	else if (tracks.size() == 1)
	{
		if (tracks[0].age >= 3)
		{
			copy_Track(&Newobservetrack, &tracks[0]);
			preCelectedpoint = tracks[0].center;
			have_Newobservetrack = 1;
		}
		else
		{
			have_Newobservetrack = 0;
		}
	}
	else
	{
		have_Newobservetrack = 0;
	}
}


void track_ahp::comprehensive(vector<Point3f> centers, Point2f m_preCel, vector<double> m_armorAngle) //, vector<int> car_type
{
	getattribute(centers, m_preCel, m_armorAngle); //, car_type
	predictNewLocationsOfTracks();   //根据位置进行卡尔曼预测
	detectionToTrackAssignment();	//匈牙利匹配
	updataAssignedTracks();			 //分配好的轨迹更新
	updataUnassignedTracks();		 //未分配的轨迹更新
	deletedLostTracks();			 //删除丢失的轨迹
	createNewTracks();				 //创建新轨迹
	the_selected_target();

	centroids.clear();
	Angles.clear();
	assignments.clear();
	unassignedTrack.clear();
	unassignedDetection.clear();
	dis.clear();
	heights.clear();
}



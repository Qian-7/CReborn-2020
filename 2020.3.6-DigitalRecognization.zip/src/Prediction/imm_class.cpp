﻿#include "Prediction/imm_class.h"

imm::imm() {}

void imm::imm_init(Point2f pos)
{
	Mat x0 = (Mat_<float>(6, 1) << pos.x, pos.y, 0, 0, 0, 0);
	u_IMM = (Mat_<float>(MODEL_SIZE, 1) << 0.34, 0.33, 0.33);			//IMM算法模型概率
	Mat diag = (Mat_<float>(6, 1) << 1000, 1000, 50, 50, 5, 5); //初始状态协方差矩阵
	kalman_XP temp;
	temp.X = x0;
	temp.P = Mat::diag(diag);
	mix_model_IMM.x_pro = temp.X;
	mix_model_IMM.P = temp.P;
	for (int i = 0; i < MODEL_SIZE; i++)
	{
		XP_IMM.push_back(temp);
	}
}

vector<Mat> imm::Interacting()
{
	vector<Mat> uij, x0j, P0j;
	c_j = (pij.t()) * u_IMM;
	for (int i = 0; i < MODEL_SIZE; i++) //计算模型混合概率
	{
		Mat_<float> temp;
		temp.setTo(0);
		temp = ((pij.colRange(i, i + 1)).mul(u_IMM));
		temp = temp / c_j.at<float>(i);
//cout<<"uij"<<temp.t()<<endl;
		uij.push_back(temp);
	}
	//计算各模型滤波初始化条件
	for (int i = 0; i < MODEL_SIZE; i++) //各模型滤波初始状态
	{
		Mat_<float> temp1(XP_IMM[0].X.size(), CV_32FC1);
		temp1.setTo(0);
		for (int j = 0; j < MODEL_SIZE; j++)
		{
			temp1 += XP_IMM[i].X * uij[i].at<float>(j);
		}
		x0j.push_back(temp1);
		P0j.push_back(temp1);
	}
	for (int i = 0; i < MODEL_SIZE; i++) //各模型滤波初始状态协方差矩阵
	{
		Mat temp1(XP_IMM[0].P.size(), CV_32FC1);
		temp1.setTo(0);
		for (int j = 0; j < MODEL_SIZE; j++)
		{
			temp1 += (XP_IMM[i].P + ((XP_IMM[i].X - x0j[i]) * (XP_IMM[i].X - x0j[i]).t())) * uij[i].at<float>(j);
		}
		P0j.push_back(temp1);
	}
	return P0j;
}

mix_model imm::Model_mix(vector<kalman_XP> XP) //u:模型概率
{
	if (XP.size() == u_IMM.rows)
	{
		mix_model return_mix_model;
		Mat_<float> x_pro(XP[0].X.size(), XP[0].X.type()), P(XP[0].P.size(), XP[0].P.type());
		x_pro.setTo(0);
		P.setTo(0);
		int size = XP.size();
		for (int i = 0; i < size; i++)
		{
			x_pro += XP[i].X * u_IMM.at<float>(i);
		}
		for (int i = 0; i < size; i++)
		{
			Mat_<float> temp1, temp2;
			temp1 = XP[i].X - x_pro;
			cv::gemm(temp1, temp1, 1, Mat(), 1, temp2, GEMM_2_T);
			P += (XP[i].P + temp2) * u_IMM.at<float>(i); //(P1 + [x1 - x_pro] * [x1 - x_pro]')*u(1)
		}
		return_mix_model.x_pro = x_pro;
		return_mix_model.P = P;
		return return_mix_model;
	}
	else
		return mix_model();
}

void imm::Model_P_up(vector<kalman_eS> eS)
{

	if (eS.size() == c_j.rows)
	{
		int size = eS.size();
		Mat_<float> Lfun(1, size), Lfun_normalize(1, size);
		float Lfun_all = 0;
		for (int i = 0; i < size; i++)
		{
			Mat_<float> temp1;
			float temp1_f;
//cout<<"eS[i].S.inv():"<<eS[i].S.inv()<<endl;
			temp1 = eS[i].e.t() * eS[i].S.inv() * eS[i].e;
			temp1_f = temp1.at<float>(0);
//cout<<"temp1_f:"<<temp1_f<<endl;
			float t = -temp1_f / 2.0;
//cout<<"sqrt(abs(2 * CV_PI * determinant(eS[i].S))):"<<sqrt(abs(2 * CV_PI * determinant(eS[i].S)))<<endl;
//cout<<"exp(t):"<<exp(t)<<endl;
			Lfun.at<float>(i) = (1 / sqrt(abs(2 * CV_PI * determinant(eS[i].S)))) * exp(t);
			Lfun_all += Lfun.at<float>(i);
		}
//cout<<"Lfun:"<<Lfun<<endl;
		Lfun_normalize = Lfun / Lfun_all;//
		Mat_<float> c = Lfun_normalize * c_j;
		Mat_<float> u = ((Lfun_normalize.t()).mul(c_j)) / c.at<float>(0);
		u_IMM = u;
		cout << "moxinggailv:" << u_IMM.t() << endl;
		bool flag = 0;
		for(int i = 0; i < size; i++)
		{
			if(isnan(u_IMM.at<float>(i)))
			{
				u_IMM.at<float>(i)=1;
				flag = 1;break;
				waitKey(0);
			}
			
			
		}
		if(flag)
			{u_IMM.at<float>(0)=0.5;u_IMM.at<float>(1)=0.499;u_IMM.at<float>(2)=0.001;}
		cout << "moxinggailv" << u_IMM.t() << endl;
	}
	//else
	//cout << eS.size() << " " << c_j.rows << endl;
}

void imm::kalman_init(KalmanFilter *kalmanFilter, Point2f pos)
{

	//CV模型
	kalmanFilter[0].init(6, 2, 0, CV_32F);
	kalmanFilter[0].statePost.setTo(0); //系统初始状态 x(0)    前一状态校正后的值
	kalmanFilter[0].statePost.at<float>(0, 0) = pos.x;
	kalmanFilter[0].statePost.at<float>(1, 0) = pos.y;
	kalmanFilter[0].transitionMatrix = (Mat_<float>(6, 6) << 1, 0, T, 0, 0, 0,\
															 0, 1, 0, T, 0, 0,\
															 0, 0, 1, 0, 0, 0,\
															 0, 0, 0, 1, 0, 0,\
															 0, 0, 0, 0, 1, 0,\
															 0, 0, 0, 0, 0, 1);
	//转移矩阵A  x,y,z,x',y',z',x'',y'',z''
	setIdentity(kalmanFilter[0].measurementMatrix);						 //测量矩阵H
	setIdentity(kalmanFilter[0].processNoiseCov, Scalar::all(1));	 //系统噪声方差矩阵Q
	float cv11, cv12, cv21, cv22;
	cv11 = pow(T, 3)/3.f;
	cv12 = pow(T, 2)/2.f;
	cv21 = pow(T, 2)/2.f;
	cv22 = T;
	//kalmanFilter[0].processNoiseCov = (Mat_<float>(6, 6) << cv11, 0, cv12, 0, 0, 0,\
															0, cv11, 0, cv12, 0, 0,\
															cv21, 0, cv22, 0, 0, 0,\
															0, cv21, 0, cv22, 0, 0,\
															0, 0, 0, 0, 0, 0,\
															0, 0, 0, 0, 0, 0)*100.0;
	setIdentity(kalmanFilter[0].processNoiseCov, Scalar::all(0.1));	 //系统噪声方差矩阵Q
	//setIdentity(kalmanFilter[0].measurementNoiseCov, Scalar::all(25.0)); //测量噪声方差矩阵R
	kalmanFilter[0].measurementNoiseCov = (Mat_<float>(2, 2) << 25, 0, 0, 25);
	setIdentity(kalmanFilter[0].errorCovPost, Scalar::all(1)); //后验错误估计协方差矩阵P

	//CA模型
	kalmanFilter[1].init(6, 2, 0, CV_32F);
	kalmanFilter[1].statePost.setTo(0); //系统初始状态 x(0)    前一状态校正后的值
	kalmanFilter[1].statePost.at<float>(0, 0) = pos.x;
	kalmanFilter[1].statePost.at<float>(1, 0) = pos.y;
	kalmanFilter[1].transitionMatrix = (Mat_<float>(6, 6) << 1, 0, T, 0, (T * T) / 2.0, 0,\
															 0, 1, 0, T, 0, (T * T) / 2.0,\
															 0, 0, 1, 0, T, 0,\
															 0, 0, 0, 1, 0, T,\
															 0, 0, 0, 0, 1, 0,\
															 0, 0, 0, 0, 0, 1);
	//转移矩阵A  x,y,z,x',y',z',x'',y'',z''
	float sigma_v = 5.0; //量测方根
	float sigma_w = 200;		//加速度先验均方差, 常速度模型应取小一些
	float temp2 = pow(T, 2), temp3 = pow(T, 3), temp4 = pow(T, 4), temp5 = pow(T, 5);
	//kalmanFilter[1].processNoiseCov = (Mat_<float>(6, 6) << temp5/20., 0, temp4/8., 0, temp3/6., 0, \
															0, temp5/20., 0, temp4/8., 0, temp3/6., \
															temp4/8., 0, temp3/3., 0, temp2/2., 0, \
															0, temp4/8., 0, temp3/3., 0, temp2/2., \
															temp3/6., 0, temp2/2., 0, T, 0, \
															0, temp3/6., 0, temp2/2., 0, T)*sigma_w;
		
//系统噪声方差矩阵Q
	setIdentity(kalmanFilter[1].processNoiseCov, Scalar::all(0.1));
	setIdentity(kalmanFilter[1].measurementMatrix); //测量矩阵H
	//setIdentity(kalmanFilter[1].measurementNoiseCov, Scalar::all(sigma_v * sigma_v));
	kalmanFilter[1].measurementNoiseCov = (Mat_<float>(2, 2) << 25, 0, 0, 25);
	setIdentity(kalmanFilter[1].errorCovPost, Scalar::all(1)); //后验错误估计协方差矩阵P

	//CS模型
	kalmanFilter[2].init(6, 2, 0, CV_32F);
	kalmanFilter[2].statePost.setTo(0); //系统初始状态 x(0)    前一状态校正后的值
	kalmanFilter[2].statePost.at<float>(0, 0) = pos.x;
	kalmanFilter[2].statePost.at<float>(1, 0) = pos.y;
	kalmanFilter[2].transitionMatrix = (Mat_<float>(6, 6) << 1, 0, T, 0, (a*T - 1 + exp(-a * T)) / pow(a, 2), 0,\
															 0, 1, 0, T, 0, (a*T - 1 + exp(-a * T)) / pow(a, 2),\
															 0, 0, 1, 0, (1 - exp(-a * T)) / a, 0,\
															 0, 0, 0, 1, 0, (1 - exp(-a * T)) / a,\
															 0, 0, 0, 0, exp(-a * T), 0,\
															 0, 0, 0, 0, 0, exp(-a * T));
	float q11, q12, q13, q21, q22, q23, q31, q32, q33;
	q11 = (1 - exp(-2.f * a*T) + 2.f * a*T + 2.f * pow(a,3) * pow(T, 3) / 3.f * pow(T, 2) - 2.f * pow(a, 2) - 4.f * a*T*exp(-a * T)) / (2.f * pow(a, 5));
	q12 = (exp(-2.f * a*T) + 1.f - 2.f * exp(-a * T) + 2.f * a*T*exp(-a * T) - 2.f * a*T + pow(a, 2) * pow(T, 2)) / (2.f * pow(a, 4));
	q13 = (1.f - exp(-2.f * a*T) - 2.f * a*T*exp(-a * T)) / (2.f * pow(a, 3));
	q21 = q12;
	q22 = (4.f * exp(-a * T) - 3.f - exp(-2.f * a*T) + 2.f * a*T) / (2.f * pow(a, 3));
	q23 = (exp(-2.f * a*T) + 1.f - 2.f * exp(-a * T)) / (2.f * pow(a, 2));
	q31 = q13;
	q32 = q23;
	q33 = (1.f - exp(-2.f * a*T)) / (2.f * a);
	kalmanFilter[2].processNoiseCov = 2.f * a * (Mat_<float>(6, 6) << q11, 0, q12, 0, q13, 0,\
																	0, q11, 0, q12, 0, q13,\
																	q21, 0, q22, 0, q23, 0,\
																	0, q21, 0, q22, 0, q23,\
																	q31, 0, q32, 0, q33, 0,\
																	0, q31, 0, q32, 0, q33)*200.0f;
	kalmanFilter[2].measurementNoiseCov = (Mat_<float>(2, 2) << 25, 0, 0, 25);
	setIdentity(kalmanFilter[2].measurementMatrix); //测量矩阵H
	setIdentity(kalmanFilter[2].errorCovPost, Scalar::all(1)); //后验错误估计协方差矩阵P

}

vector<Mat> imm::predict_kalman(KalmanFilter *kalmanFilter)
{
	vector<Mat> predict;

	predict.push_back(kalmanFilter[0].predict());
	predict.push_back(kalmanFilter[1].predict());

	Mat F = (Mat_<float>(6, 6) << 1, 0, T, 0, (T * T) / 2.0, 0,\
								0, 1, 0, T, 0, (T * T) / 2.0,\
								0, 0, 1, 0, T, 0,\
								0, 0, 0, 1, 0, T,\
								0, 0, 0, 0, 1, 0,\
								0, 0, 0, 0, 0, 1);
	kalmanFilter[2].statePre = F * kalmanFilter[2].statePost;
	double cax,cay;
	if(kalmanFilter[2].statePre.at<float>(4)<0)
		cax = (4 - CV_PI) / CV_PI * pow((-a_max + kalmanFilter[2].statePost.at<float>(4)),2);
	else
		cax = (4 - CV_PI) / CV_PI * pow((a_max - kalmanFilter[2].statePost.at<float>(4)), 2);
	if (kalmanFilter[2].statePre.at<float>(5) < 0)
		cay = (4 - CV_PI) / CV_PI * pow((-a_max + kalmanFilter[2].statePost.at<float>(5)), 2);
	else
		cay = (4 - CV_PI) / CV_PI * pow((a_max - kalmanFilter[2].statePost.at<float>(5)), 2);
	Mat ca = (Mat_<float>(6, 6) <<  cax, 0, cax, 0, cax, 0,
									0, cay, 0, cay, 0, cay,
									cax, 0, cax, 0, cax, 0,
									0, cay, 0, cay, 0, cay,
									cax, 0, cax, 0, cax, 0,
									0, cay, 0, cay, 0, cay);
	kalmanFilter[2].errorCovPre = kalmanFilter[2].transitionMatrix*kalmanFilter[2].errorCovPost*kalmanFilter[2].transitionMatrix.t() + ca*kalmanFilter[2].processNoiseCov;
	kalmanFilter[2].statePre.copyTo(kalmanFilter[2].statePost); 
	predict.push_back(kalmanFilter[2].statePre);
	return predict;
}

void imm::correct_kalman(KalmanFilter *kalmanFilter, Point2f pos)
{
	Mat measurement = Mat::zeros(2, 1, CV_32F);
	measurement.at<float>(0) = pos.x;
	measurement.at<float>(1) = pos.y;

	//cout<<"kalmanFilter[0]beforecorrect:"<<kalmanFilter[0].statePost.t()<<endl;
	//cout<<"kalmanFilter[1]beforecorrect:"<<kalmanFilter[1].statePost.t()<<endl;
	kalmanFilter[0].correct(measurement);
	kalmanFilter[1].correct(measurement);
	kalmanFilter[2].correct(measurement);
	//cout<<"kalmanFilter[0]aftercorrect:"<<kalmanFilter[0].statePost<<endl;
	//cout<<"kalmanFilter[1]aftercorrect:"<<kalmanFilter[1].statePost<<endl;

}

void imm::kalman_imm_parameter(KalmanFilter *kalmanFilter)
{
	for (int i = 0; i < MODEL_SIZE; i++)
	{
		Mat_<float> temp1, temp2, temp3, temp4;
		kalman_XP temp_xp;
		kalman_eS temp_es;
		temp_xp.X = kalmanFilter[i].statePost;
		temp_es.S = kalmanFilter[i].temp3;
		temp_es.e = kalmanFilter[i].temp5;
		/*temp1 = kalmanFilter[i].gain * kalmanFilter[i].measurementMatrix;
		Mat_<float> I = Mat::eye(Size(temp1.cols, temp1.rows), CV_32F);
		temp2 = kalmanFilter[i].gain * kalmanFilter[i].measurementNoiseCov;
		gemm(temp2, kalmanFilter[i].gain, 1, Mat(), 1, temp3, GEMM_2_T);
		temp4 = (I - temp1) * kalmanFilter[i].errorCovPre * (I - temp1).t() + temp3;*/
		temp_xp.P = kalmanFilter[i].errorCovPost;// temp4
		XP_IMM.push_back(temp_xp);
		eS_IMM.push_back(temp_es);
	}
}

void imm::imm_kalman_init(KalmanFilter *kalmanFilter, Point2f pos)
{
	imm_init(pos);
	kalman_init(kalmanFilter, pos);
}

Mat imm::imm_predict(KalmanFilter *kalmanFilter, bool truepre)
{
	vector<Mat> predict_1, vec_P;

	
	if (!truepre)
	{
		vec_P = Interacting(); //交互（只针对IMM算法）
		kalmanFilter[0].statePost = vec_P[0];
		kalmanFilter[1].statePost = vec_P[1];
		kalmanFilter[2].statePost = vec_P[2];
		kalmanFilter[0].errorCovPost = vec_P[3];
		kalmanFilter[1].errorCovPost = vec_P[4];
		kalmanFilter[2].errorCovPost = vec_P[5];
	}
	predict_1 = predict_kalman(kalmanFilter);
	Mat x_pro(predict_1[0].size(), CV_32F);
	x_pro = Scalar::all(0);
	for (int i = 0; i < predict_1.size(); i++)
	{
		x_pro += predict_1[i] * u_IMM.at<float>(i);
	}
	return x_pro;
}

void imm::imm_correct(KalmanFilter *kalmanFilter, Point2f pos)
{
	correct_kalman(kalmanFilter, pos);
//cout << "kalmanFilter[0].statePost:" << kalmanFilter[0].statePost.t() <<endl;
//cout << "kalmanFilter[1].statePost:" << kalmanFilter[1].statePost.t() <<endl;
//cout << "kalmanFilter[2].statePost:" << kalmanFilter[2].statePost.t() <<endl;

	kalman_imm_parameter(kalmanFilter);
	if (XP_IMM.size() > MODEL_SIZE)
	{
		XP_IMM.erase(XP_IMM.begin(), XP_IMM.begin() + MODEL_SIZE);
	}
	if (eS_IMM.size() > MODEL_SIZE)
	{
		eS_IMM.erase(eS_IMM.begin(), eS_IMM.begin() + MODEL_SIZE);
	}
	Model_P_up(eS_IMM);
	mix_model_IMM = Model_mix(XP_IMM);

	//kalmanFilter[0].statePre = mix_model_IMM.x_pro;
	//kalmanFilter[1].statePre = mix_model_IMM.x_pro;
	//kalmanFilter[2].statePre = mix_model_IMM.x_pro;

cout << "fliter:" << mix_model_IMM.x_pro.t() <<endl;
}

Point2f imm::mix_model_point()
{
	Point2f temp(mix_model_IMM.x_pro.at<float>(0), mix_model_IMM.x_pro.at<float>(1));
	//cout << "mix_model_IMM.x_pro:" << mix_model_IMM.x_pro << endl;
	return temp;
}

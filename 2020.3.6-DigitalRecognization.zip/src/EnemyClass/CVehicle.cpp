﻿#include "EnemyClass/CVehicle.h"

CVehicle::CVehicle()
{
}
CVehicle::CVehicle(Rect PosRect, uchar Type)
{
	m_VehiclePosRect = PosRect;
	m_VehicleType = Type;
}

CVehicle::~CVehicle()
{
	Clear();
}

void CVehicle::Clear()
{
	m_VehicleArmourVector.clear();
}

void CVehicle::Show(Mat DisplayImg)
{
	rectangle(DisplayImg, m_VehiclePosRect, Scalar(0, 0, 255), 2, LINE_AA);
	if (m_VehicleArmourVector.size() == 0)
		return;
    for (int i = 0; i < (int)m_VehicleArmourVector.size(); i++)
	{
		m_VehicleArmourVector[i].Show(DisplayImg);
	}
}

﻿#include "EnemyClass/CArmour.h"

CArmour::CArmour() {}

CArmour::CArmour(RotatedRect LeftLight, RotatedRect RightLight)
{
	m_ArmourLeftLight = LeftLight;
	m_ArmourRightLight = RightLight;
	m_ArmourCenter = (LeftLight.center + RightLight.center) / 2.0f;
	m_ArmourRect = LeftLight.boundingRect() | RightLight.boundingRect();
}

vector<float> extractFeatureData(Mat &txtImage)
{
	vector<float>descriptorc2;
	Mat trainTempImg = Mat::zeros(Size(64, 128), CV_8UC1);

	resize(txtImage, trainTempImg, trainTempImg.size());

	HOGDescriptor *hog2 = new HOGDescriptor(Size(64, 128), Size(16, 16), Size(8, 8), Size(8, 8), 9);

	hog2->compute(trainTempImg, descriptorc2, Size(8, 8), Size(0, 0));
	// cout << "HOG描述子向量维数    " << descriptorc2.size() << endl;

	Mat SVMtrainMat = Mat(1, descriptorc2.size(), CV_32FC1);
	return descriptorc2;
}

void CArmour::DigitalRecognization(Mat src, Ptr<SVM> svm_test)
{	
	if(m_ArmourRect.area()<2000) return;
	if(m_ArmourRect.tl().y < 20 )	return ;

	Rect rect_temp = m_ArmourRect;
	rect_temp += Point(m_ArmourLeftLight.size.width , 0);

	rect_temp -= Size(2 * m_ArmourLeftLight.size.width, 0);
	rect_temp -= Point(0, m_ArmourLeftLight.size.height / 2);

	rect_temp += Size(0, m_ArmourLeftLight.size.height - 20);

	vector<vector<Point>> contours;
	vector<Point> temp_points;

	if(rect_temp.br().y > 479) rect_temp.height = 479-rect_temp.tl().y;

	Mat number = src(rect_temp);

	imshow("nu", number);//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	cvtColor(number, number, COLOR_RGB2GRAY); //灰度图
	threshold(number, number, 0, 255, THRESH_OTSU); //大津法根据亮度识别
	findContours(number, contours, -1, CHAIN_APPROX_NONE);

	for (int j = 0; j < contours.size(); j++) { //去除噪音
		if (contours[j].size() < 20)
			continue;
		if (j != 0) {
			if (contours[j].size() > temp_points.size()) {
				temp_points = contours[j];
			}
		}
		else {
			temp_points = contours[j];
		}
	}

	Rect rect_temp1 = boundingRect(temp_points);
	Rect temp_r = Rect(rect_temp1.x + rect_temp.tl().x, rect_temp1.y + rect_temp.tl().y, rect_temp1.width, rect_temp1.height);
	Mat temp = src(temp_r);

	vector<float> descriptorc = extractFeatureData(temp);             //结果数组   

	//将计算好的HOG描述子复制到样本特征矩阵data_mat  
	Mat data_mat = Mat(1, 3780, CV_32FC1);
	for (int i = 0; i < descriptorc.size(); i++)
	{
		data_mat.at<float>(0, i) = descriptorc[i];//第i个样本的特征向量中的第n个元素  
	}

	digital = svm_test->predict(data_mat);//检测结果  

	putText(number, to_string(digital), Point(temp_r.tl().x + 5, temp_r.br().y - 20), FONT_HERSHEY_PLAIN, 2.0, Scalar(0, 0, 255), 1);
	
	imshow("number",number);//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
}

CArmour::CArmour(BrightLight LeftLight, BrightLight RightLight)
{
	m_ArmourLeftLight = LeftLight.minarearect;
	m_ArmourRightLight = RightLight.minarearect;
	m_ArmourLeftBrightLight = LeftLight;
	m_ArmourRightBrightLight = RightLight;
	m_ArmourCenter = (LeftLight.center + RightLight.center) / 2.0f;
	m_ArmourRect = LeftLight.minarearect.boundingRect() | RightLight.minarearect.boundingRect();
}
CArmour::CArmour(LightBlob LeftLight, LightBlob RightLight)
{
	m_ArmourLeftLight = LeftLight.rect;
	m_ArmourRightLight = RightLight.rect;
	m_ArmourCenter = (LeftLight.rect.center + RightLight.rect.center) / 2.0f;
	m_ArmourRect = LeftLight.rect.boundingRect() | RightLight.rect.boundingRect();

}

CArmour::CArmour(Rect rect)
{
	m_ArmourRect = rect;
	m_ArmourCenter = ((Point2f)rect.tl() + (Point2f)rect.br()) / 2.0f;
}

CArmour::~CArmour() {}

void CArmour::Show(Mat displayImg)
{
	line(displayImg, Point(0, m_ArmourCenter.y), Point(displayImg.cols, m_ArmourCenter.y), Scalar(0, 255, 0), 2);
	line(displayImg, Point(m_ArmourCenter.x, 0), Point(m_ArmourCenter.x, displayImg.rows), Scalar(0, 255, 0), 2);
	rectangle(displayImg,m_ArmourRect, Scalar(0, 255, 0), 2);
	circle(displayImg, m_ArmourCenter, 6, Scalar(0, 0, 255), -1);
}

void CArmour::Enlarge(Point2f tl)
{
	m_ArmourLeftLight.center = m_ArmourLeftLight.center + tl;
	m_ArmourRightLight.center = m_ArmourRightLight.center + tl;
	m_ArmourCenter = m_ArmourCenter + tl;
	m_ArmourRect.tl() = m_ArmourRect.tl() + tl;
	m_ArmourRect.br() = m_ArmourRect.br() + tl;
}

vector<Point2f> CArmour::GetPnpPoints()
{
	vector<Point2f> points;
	Point2f dot_left[4], dot_right[4], dot[4];
	m_ArmourLeftLight.points(dot_left);
	m_ArmourRightLight.points(dot_right);
	if (dot_left[0].y < dot_left[1].y)
	{
		dot[0] = (dot_left[1] + dot_left[2]) / 2;
		dot[1] = (dot_left[0] + dot_left[3]) / 2;
	}
	else
	{
		dot[0] = (dot_left[0] + dot_left[3]) / 2;
		dot[1] = (dot_left[1] + dot_left[2]) / 2;
	}

	if (dot_right[2].y < dot_right[3].y)
	{
		dot[2] = (dot_right[1] + dot_right[2]) / 2;
		dot[3] = (dot_right[0] + dot_right[3]) / 2;
	}
	else
	{
		dot[2] = (dot_right[0] + dot_right[3]) / 2;
		dot[3] = (dot_right[1] + dot_right[2]) / 2;
	}
	for (int i = 0; i < 4; i++)
	{
		points.push_back(dot[i]);
	}
	return points;
}

vector<Point2f> CArmour::GetPnpPoints(int a)
{
	vector<Point2f> points;
	Point2f dot_left[4], dot_right[4], dot[4];
	dot[0] = m_ArmourLeftBrightLight.bottom;
	dot[1] = m_ArmourLeftBrightLight.top;
	dot[3] = m_ArmourRightBrightLight.bottom;
	dot[2] = m_ArmourRightBrightLight.top;
// cout<<"points:";
	for (int i = 0; i < 4; i++)
	{
// cout<<dot[i]<<" ";
		points.push_back((Point2f)dot[i]);
	}
// cout<<endl;
	return points;
}






﻿#include "Utility/Params.h"
//~~~~~~~~~~~~~~~~~~预处理指令~~~~~~~~~~~~~~~~~~~~~~

//~~~~~~~~~~~~~~~~~~~~~~~~函数~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

bool RotatedXvalueSort(RotatedRect a, RotatedRect b)
{
	return a.center.x < b.center.x;
}

bool LightXvalueSort(BrightLight a, BrightLight b)
{
	return a.center.x < b.center.x;
}

bool RectAreaSort(Rect a, Rect b)
{
	return a.area() > b.area();
}

bool MakeRectInLimit(Rect &rect, Mat limitImg)
{
	Point tl, br;
	tl.x = rect.tl().x <= 0 ? 1 : rect.tl().x;
	tl.y = rect.tl().y <= 0 ? 1 : rect.tl().y;
	br.x = rect.br().x >= limitImg.cols ? limitImg.cols - 1 : rect.br().x;
	br.y = rect.br().y >= limitImg.rows ? limitImg.rows - 1 : rect.br().y;
	if (tl.x >= br.x || tl.y >= br.y)
		return false;
	rect = Rect(tl, br);
	return true;
}
